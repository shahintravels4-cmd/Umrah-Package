import React from 'react';
import { BUSINESS_INFO } from '../data/business';
import { ArrowDown, MessageCircle, Sparkles } from 'lucide-react';
import heroKaabaImg from '../assets/images/hero_masjid_al_haram_1792051325520.jpg';

interface HeroProps {
  onExplorePackages: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onExplorePackages }) => {
  const whatsappUrl = `https://wa.me/${BUSINESS_INFO.whatsappNumber}?text=${encodeURIComponent(
    'Assalamualaikum, I would like to enquire about your Umrah tour packages.'
  )}`;

  return (
    <section id="home" className="relative overflow-hidden bg-[#FAF8F3] pt-6 pb-12 lg:pt-10 lg:pb-16">
      {/* Subtle geometric pattern ambient layer */}
      <div className="absolute inset-0 bg-islamic-pattern opacity-60 pointer-events-none" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
          {/* Left Text Column */}
          <div className="lg:col-span-7 flex flex-col items-start text-left z-10">
            {/* Quiet trust label */}
            <div className="inline-flex items-center gap-2 mb-4 text-xs font-semibold text-[#0F4C4C] tracking-wider uppercase">
              <span className="w-1.5 h-1.5 rounded-full bg-[#C9A45C]" />
              <span>Dedicated Hajj & Umrah Tour Specialists</span>
            </div>

            <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-[3.25rem] font-serif font-bold tracking-tight text-[#082B49] leading-[1.18] max-w-2xl text-balance">
              {BUSINESS_INFO.headline}
            </h1>

            <p className="mt-5 text-base sm:text-lg text-[#64748B] leading-relaxed max-w-xl">
              {BUSINESS_INFO.subheadline}
            </p>

            {/* Quick departure indicator */}
            <div className="mt-4 flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-[#64748B]">
              <span className="font-semibold text-[#082B49]">Direct & Group Departures:</span>
              <span>Delhi (IGI)</span>
              <span aria-hidden="true" className="text-[#C9A45C]">·</span>
              <span>Mumbai (BOM)</span>
              <span aria-hidden="true" className="text-[#C9A45C]">·</span>
              <span>14 & 15 Nights Stays</span>
            </div>

            {/* CTA Group */}
            <div className="mt-8 flex flex-col sm:flex-row items-stretch sm:items-center gap-3 w-full sm:w-auto">
              <button
                type="button"
                onClick={onExplorePackages}
                className="inline-flex items-center justify-center gap-2 px-6 py-3.5 text-sm font-semibold text-white bg-[#082B49] rounded-xl hover:bg-[#061e33] active:scale-[0.98] transition-all duration-200 shadow-md hover:shadow-lg whitespace-nowrap"
              >
                <span>Explore Umrah Packages</span>
                <ArrowDown className="w-4 h-4 text-[#C9A45C]" />
              </button>

              <a
                href={whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center gap-2 px-6 py-3.5 text-sm font-semibold text-[#082B49] bg-white border border-[#082B49]/15 rounded-xl hover:bg-[#F1E9DA]/50 hover:border-[#082B49]/30 transition-all duration-200 shadow-xs whitespace-nowrap"
              >
                <MessageCircle className="w-4 h-4 text-[#0F4C4C]" />
                <span>WhatsApp Us</span>
              </a>
            </div>

            {/* Direct contact hint for seniors and families */}
            <div className="mt-6 text-xs text-[#64748B] flex items-center gap-1.5">
              <span>Need personal guidance? Call directly:</span>
              <a
                href={`tel:${BUSINESS_INFO.phone}`}
                className="font-semibold text-[#082B49] underline decoration-[#C9A45C] hover:text-[#0F4C4C]"
              >
                {BUSINESS_INFO.phoneDisplay}
              </a>
            </div>
          </div>

          {/* Right Visual Column: Authentic High-Resolution Masjid al-Haram Photograph */}
          <div className="lg:col-span-5 relative">
            <div className="relative rounded-2xl overflow-hidden shadow-xl border border-[#082B49]/10 bg-neutral-100 aspect-[4/3] sm:aspect-[16/11] lg:aspect-[4/3]">
              <img
                src={heroKaabaImg}
                alt="The Holy Kaaba and Masjid al-Haram courtyard during peaceful dawn hours"
                referrerPolicy="no-referrer"
                loading="eager"
                className="w-full h-full object-cover transition-transform duration-700 hover:scale-[1.02]"
              />

              {/* Measured contrast scrim */}
              <div className="absolute inset-0 bg-gradient-to-t from-[#082B49]/80 via-[#082B49]/20 to-transparent" />

              {/* Bottom tranquil caption */}
              <div className="absolute bottom-4 left-4 right-4 text-white">
                <div className="flex items-center gap-1.5 text-xs text-[#C9A45C] font-medium mb-0.5">
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>The Sacred Sanctuaries</span>
                </div>
                <p className="text-sm font-serif font-medium text-white/95">
                  Masjid al-Haram, Makkah al-Mukarramah
                </p>
                <p className="text-[11px] text-white/70">
                  Transparent distances · Verified hotels · Guided pilgrimage
                </p>
              </div>
            </div>

            {/* Subtle decorative gold framing accent */}
            <div
              className="absolute -bottom-2 -right-2 w-24 h-24 border-r-2 border-b-2 border-[#C9A45C]/40 rounded-br-2xl pointer-events-none hidden sm:block"
              aria-hidden="true"
            />
          </div>
        </div>
      </div>
    </section>
  );
};
