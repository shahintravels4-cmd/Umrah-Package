import React, { useState } from 'react';
import { UMRAH_GUIDES } from '../data/business';
import { BookOpen, Check, X, ArrowRight, Sparkles, HelpCircle } from 'lucide-react';
import pilgrimsImg from '../assets/images/umrah_pilgrim_journey_1792051325780.jpg';

export const UmrahGuide: React.FC = () => {
  const [selectedGuide, setSelectedGuide] = useState<(typeof UMRAH_GUIDES)[0] | null>(null);

  return (
    <section id="guide" className="py-14 sm:py-20 bg-white border-t border-[#082B49]/8 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-12 sm:mb-16">
          <div className="inline-flex items-center gap-2 mb-2 text-xs font-semibold text-[#0F4C4C] uppercase tracking-wider">
            <BookOpen className="w-4 h-4 text-[#C9A45C]" />
            <span>Educational Pilgrim Resource</span>
          </div>
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-serif font-bold text-[#082B49] tracking-tight">
            The Umrah Guide & Resources
          </h2>
          <p className="mt-3 text-sm sm:text-base text-[#64748B]">
            Practical advice, packing recommendations, Ihram rules, and essential answers to help you prepare mentally and spiritually.
          </p>
        </div>

        {/* Highlight Banner with Authentic Pilgrim Photo */}
        <div className="relative rounded-2xl sm:rounded-3xl overflow-hidden border border-[#082B49]/10 mb-10 bg-[#FAF8F3]">
          <div className="grid grid-cols-1 lg:grid-cols-12 items-center">
            <div className="lg:col-span-5 h-64 lg:h-full relative min-h-[240px]">
              <img
                src={pilgrimsImg}
                alt="Pilgrims performing rituals in the courtyard of the Holy Mosque"
                referrerPolicy="no-referrer"
                loading="lazy"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t lg:bg-gradient-to-r from-black/50 via-transparent to-transparent" />
            </div>

            <div className="lg:col-span-7 p-6 sm:p-8 lg:p-10 flex flex-col justify-center">
              <span className="text-xs font-semibold text-[#0F4C4C] uppercase tracking-wider mb-2">
                Knowledge & Tranquility
              </span>
              <h3 className="text-xl sm:text-2xl lg:text-3xl font-serif font-bold text-[#082B49] leading-snug">
                Perform Your Umrah with Complete Peace of Mind
              </h3>
              <p className="mt-3 text-sm text-[#64748B] leading-relaxed">
                Whether this is your very first pilgrimage or you are returning to the sacred precincts of Makkah and Madinah, having clear information on packing, Ihram, and logistics ensures your time is dedicated solely to worship.
              </p>
              <div className="mt-6 flex flex-wrap items-center gap-4 text-xs font-medium text-[#082B49]">
                <span className="flex items-center gap-1.5">
                  <Check className="w-4 h-4 text-[#0F4C4C]" />
                  Step-by-step guidance
                </span>
                <span className="flex items-center gap-1.5">
                  <Check className="w-4 h-4 text-[#0F4C4C]" />
                  Verified checklist
                </span>
                <span className="flex items-center gap-1.5">
                  <Check className="w-4 h-4 text-[#0F4C4C]" />
                  Nusuk app support
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* 6 Guide Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {UMRAH_GUIDES.map((guide) => (
            <div
              key={guide.id}
              onClick={() => setSelectedGuide(guide)}
              className="bg-[#FAF8F3]/60 rounded-2xl border border-[#082B49]/10 p-6 flex flex-col justify-between hover:border-[#C9A45C]/50 hover:bg-white hover:shadow-md transition-all duration-200 cursor-pointer group"
            >
              <div>
                <div className="flex items-center justify-between gap-2 mb-3">
                  <span className="text-[11px] font-semibold text-[#0F4C4C] uppercase tracking-wider">
                    {guide.category}
                  </span>
                  <span className="text-xs text-[#64748B]">{guide.readTime}</span>
                </div>

                <h3 className="text-lg font-serif font-bold text-[#082B49] group-hover:text-[#0F4C4C] transition-colors leading-snug">
                  {guide.title}
                </h3>

                <p className="mt-2.5 text-xs text-[#64748B] leading-relaxed">
                  {guide.summary}
                </p>
              </div>

              <div className="mt-5 pt-3 border-t border-[#082B49]/5 flex items-center justify-between text-xs font-semibold text-[#082B49]">
                <span>Read Full Guide</span>
                <ArrowRight className="w-4 h-4 text-[#C9A45C] group-hover:translate-x-1 transition-transform" />
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Guide Detail Modal */}
      {selectedGuide && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-xs overflow-y-auto animate-fade-in"
          onClick={() => setSelectedGuide(null)}
          role="dialog"
          aria-modal="true"
        >
          <div
            className="relative w-full max-w-xl bg-white rounded-2xl sm:rounded-3xl shadow-2xl border border-[#082B49]/15 overflow-hidden text-left my-6"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Header */}
            <div className="bg-[#082B49] text-white p-6 relative">
              <button
                type="button"
                onClick={() => setSelectedGuide(null)}
                className="absolute top-5 right-5 p-2 rounded-full bg-white/10 hover:bg-white/20 text-white transition-colors"
                aria-label="Close guide modal"
              >
                <X className="w-5 h-5" />
              </button>
              <div className="flex items-center gap-2 text-xs text-[#C9A45C] font-semibold uppercase tracking-wider mb-1">
                <span>{selectedGuide.category}</span>
                <span aria-hidden="true">·</span>
                <span>{selectedGuide.readTime}</span>
              </div>
              <h2 className="text-xl sm:text-2xl font-serif font-bold text-white">
                {selectedGuide.title}
              </h2>
            </div>

            {/* Body */}
            <div className="p-6 sm:p-8 space-y-4 max-h-[60vh] overflow-y-auto">
              <p className="text-xs sm:text-sm text-[#64748B] pb-3 border-b border-[#082B49]/10">
                {selectedGuide.summary}
              </p>

              <div className="space-y-3">
                {selectedGuide.details.map((point, idx) => (
                  <div key={idx} className="flex items-start gap-3 text-xs sm:text-sm text-[#1F2933]">
                    <div className="w-5 h-5 rounded-full bg-[#082B49]/10 text-[#082B49] font-bold text-xs flex items-center justify-center shrink-0 mt-0.5">
                      {idx + 1}
                    </div>
                    <div className="leading-relaxed whitespace-pre-line">
                      {point}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Footer */}
            <div className="p-4 sm:p-6 bg-[#FAF8F3] border-t border-[#082B49]/10 flex items-center justify-end">
              <button
                type="button"
                onClick={() => setSelectedGuide(null)}
                className="px-5 py-2.5 text-xs font-semibold text-white bg-[#082B49] rounded-xl hover:bg-[#061e33] transition-colors"
              >
                Close Guide
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
