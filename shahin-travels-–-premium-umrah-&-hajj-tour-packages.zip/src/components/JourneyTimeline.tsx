import React from 'react';
import { JOURNEY_STEPS } from '../data/business';
import { Route } from 'lucide-react';

export const JourneyTimeline: React.FC = () => {
  return (
    <section className="py-14 sm:py-20 bg-[#FAF8F3] border-t border-[#082B49]/8 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-12 sm:mb-16">
          <div className="inline-flex items-center gap-2 mb-2 text-xs font-semibold text-[#0F4C4C] uppercase tracking-wider">
            <Route className="w-4 h-4 text-[#C9A45C]" />
            <span>Step-by-Step Guidance</span>
          </div>
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-serif font-bold text-[#082B49] tracking-tight">
            Your Umrah Journey with Shahin Travels
          </h2>
          <p className="mt-3 text-sm sm:text-base text-[#64748B]">
            From your first enquiry to your safe return, here is how we arrange your sacred pilgrimage.
          </p>
        </div>

        {/* Desktop Horizontal Timeline / Mobile Vertical Timeline */}
        <div className="relative">
          {/* Subtle connecting line for desktop */}
          <div
            className="hidden lg:block absolute top-7 left-12 right-12 h-[2px] bg-[#082B49]/15"
            aria-hidden="true"
          />

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6 sm:gap-4 relative z-10">
            {JOURNEY_STEPS.map((item, idx) => (
              <div
                key={item.step}
                className="bg-white rounded-2xl border border-[#082B49]/10 p-5 sm:p-6 flex flex-col justify-between hover:shadow-md transition-shadow relative"
              >
                {/* Step Marker */}
                <div className="flex items-center justify-between mb-4">
                  <div className="w-10 h-10 rounded-full bg-[#082B49] text-[#C9A45C] font-mono text-sm font-bold flex items-center justify-center shadow-xs">
                    {item.step}
                  </div>
                  <span className="text-[11px] font-semibold text-[#0F4C4C] uppercase tracking-wider">
                    Stage {idx + 1}
                  </span>
                </div>

                {/* Content */}
                <div>
                  <h3 className="text-base font-serif font-bold text-[#082B49] leading-snug">
                    {item.title}
                  </h3>
                  <p className="mt-2 text-xs text-[#64748B] leading-relaxed">
                    {item.description}
                  </p>
                </div>

                <div className="mt-4 pt-3 border-t border-[#082B49]/5 text-[11px] font-medium text-[#082B49]">
                  Step {idx + 1} of 5
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};
