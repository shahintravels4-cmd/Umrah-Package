import React, { useState } from 'react';

interface ShahinLogoProps {
  variant?: 'light' | 'dark';
  className?: string;
  size?: 'sm' | 'md' | 'lg';
}

export const ShahinLogo: React.FC<ShahinLogoProps> = ({
  variant = 'dark',
  className = '',
  size = 'md',
}) => {
  const [imageFailed, setImageFailed] = useState(false);

  // If a user-provided logo file exists in /logo.png or /logo.jpg, use it; otherwise fallback to the vector emblem
  const logoSrc = '/logo.png';

  const isLight = variant === 'light';

  return (
    <div className={`inline-flex items-center gap-3 select-none ${className}`}>
      {!imageFailed ? (
        <img
          src={logoSrc}
          alt="Shahin Travels Logo"
          className={`object-contain transition-opacity duration-200 ${
            size === 'sm' ? 'h-8' : size === 'lg' ? 'h-14' : 'h-10'
          }`}
          onError={() => setImageFailed(true)}
        />
      ) : null}

      {imageFailed && (
        <div className="flex items-center gap-3">
          {/* Elegant Falcon & Crescent Brand Emblem */}
          <div
            className={`flex items-center justify-center rounded-xl transition-all duration-300 shadow-sm shrink-0 ${
              isLight
                ? 'bg-[#C9A45C]/15 border border-[#C9A45C]/40 text-[#C9A45C]'
                : 'bg-[#082B49] border border-[#C9A45C]/30 text-[#C9A45C]'
            } ${size === 'sm' ? 'w-8 h-8' : size === 'lg' ? 'w-12 h-12' : 'w-10 h-10'}`}
          >
            <svg
              viewBox="0 0 36 36"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
              className={size === 'sm' ? 'w-5 h-5' : size === 'lg' ? 'w-7 h-7' : 'w-6 h-6'}
            >
              {/* Subtle crescent arc */}
              <path
                d="M18 4C10.268 4 4 10.268 4 18C4 25.732 10.268 32 18 32C21.866 32 25.366 30.433 27.899 27.899C20.5 28.5 15 22.5 15 15C15 10.5 17 6.8 20 4.5C19.34 4.18 18.68 4 18 4Z"
                fill="currentColor"
                fillOpacity="0.85"
              />
              {/* Soaring Shahin (Falcon) Wings silhouette */}
              <path
                d="M16 11C21 11 28 14 31 19C28 18.5 25 18.2 21 20C24 21 27 22.5 29 25C25 24 21 23 18 25C19 22.5 19 18 16 11Z"
                fill="#C9A45C"
              />
              <circle cx="21" cy="13" r="1.5" fill="#FAF8F3" />
            </svg>
          </div>

          {/* Typography Lockup */}
          <div className="flex flex-col text-left">
            <span
              className={`font-serif tracking-tight font-bold uppercase transition-colors ${
                isLight ? 'text-white' : 'text-[#082B49]'
              } ${size === 'sm' ? 'text-sm' : size === 'lg' ? 'text-xl' : 'text-lg'}`}
            >
              Shahin Travels
            </span>
            <span
              className={`text-[9px] tracking-[0.22em] font-medium uppercase ${
                isLight ? 'text-[#C9A45C]' : 'text-[#0F4C4C]'
              }`}
            >
              HAJJ | UMRAH | TOURS | TRAVEL
            </span>
          </div>
        </div>
      )}
    </div>
  );
};
