import React from 'react';
import { UmrahPackage } from '../data/packages';
import { BUSINESS_INFO } from '../data/business';
import { MapPin, Calendar, Plane, Clock, MessageCircle, ArrowRight } from 'lucide-react';

interface PackageCardProps {
  pkg: UmrahPackage;
  onViewDetails: (pkg: UmrahPackage) => void;
  onEnquireNow: (pkg: UmrahPackage) => void;
}

export const PackageCard: React.FC<PackageCardProps> = ({
  pkg,
  onViewDetails,
  onEnquireNow,
}) => {
  const whatsappUrl = `https://wa.me/${BUSINESS_INFO.whatsappNumber}?text=${encodeURIComponent(
    `Assalamualaikum, I would like details for the ${pkg.name} Umrah package.`
  )}`;

  // Category badge colors (subtle and refined)
  const categoryBadgeColors = {
    Budget: 'text-amber-800 bg-amber-50 border-amber-200/60',
    Bronze: 'text-orange-900 bg-orange-50/70 border-orange-200/60',
    Silver: 'text-slate-700 bg-slate-100 border-slate-300/60',
    Gold: 'text-[#082B49] bg-[#C9A45C]/15 border-[#C9A45C]/40',
    Diamond: 'text-[#082B49] bg-cyan-50/80 border-cyan-200/60',
  }[pkg.category] || 'text-slate-700 bg-slate-50 border-slate-200';

  return (
    <div className="bg-white rounded-2xl border border-[#082B49]/10 shadow-xs hover:shadow-md transition-all duration-200 flex flex-col justify-between overflow-hidden group">
      {/* Card Header */}
      <div className="p-5 sm:p-6 pb-4">
        {/* Unboxed clean metadata line */}
        <div className="flex items-center justify-between gap-2 mb-2.5">
          <div className="flex items-center gap-2 text-xs text-[#64748B]">
            <span className="font-semibold text-[#082B49]">{pkg.departureCity} Departure</span>
            <span aria-hidden="true" className="text-[#C9A45C]">·</span>
            <span>{pkg.duration}</span>
          </div>

          <span className={`text-[11px] font-semibold px-2.5 py-0.5 rounded-md border ${categoryBadgeColors}`}>
            {pkg.tierDisplay}
          </span>
        </div>

        {/* Package Title */}
        <h3 className="text-lg sm:text-xl font-serif font-bold text-[#082B49] group-hover:text-[#0F4C4C] transition-colors leading-snug">
          {pkg.name}
        </h3>

        {/* Airline & Departure Schedule */}
        <div className="mt-3.5 pt-3 border-t border-[#082B49]/5 space-y-2 text-xs text-[#1F2933]">
          <div className="flex items-center gap-2 text-[#64748B]">
            <Plane className="w-3.5 h-3.5 text-[#0F4C4C] shrink-0" />
            <span className="font-medium text-[#1F2933]">{pkg.airlineDisplay}</span>
          </div>

          <div className="flex items-center gap-2 text-[#64748B]">
            <Calendar className="w-3.5 h-3.5 text-[#0F4C4C] shrink-0" />
            <span className="truncate">{pkg.departureDates[0]}</span>
          </div>
        </div>

        {/* Hotel & Proximity Summary */}
        <div className="mt-4 p-3 rounded-xl bg-[#FAF8F3] border border-[#082B49]/5 space-y-2 text-xs">
          <div>
            <div className="flex items-center justify-between text-[11px] text-[#64748B] mb-0.5">
              <span className="font-semibold text-[#082B49]">Makkah Stay</span>
              <span className="text-[#0F4C4C] font-medium">{pkg.makkahDistance}</span>
            </div>
            <p className="text-[#1F2933] font-medium truncate">{pkg.makkahHotel}</p>
          </div>

          <div className="pt-2 border-t border-[#082B49]/5">
            <div className="flex items-center justify-between text-[11px] text-[#64748B] mb-0.5">
              <span className="font-semibold text-[#082B49]">Madinah Stay</span>
              <span className="text-[#0F4C4C] font-medium">{pkg.madinahDistance}</span>
            </div>
            <p className="text-[#1F2933] font-medium truncate">{pkg.madinahHotel}</p>
          </div>
        </div>
      </div>

      {/* Card Footer: Pricing & Action Buttons */}
      <div className="px-5 sm:px-6 pb-5 pt-3 bg-white border-t border-[#082B49]/5">
        <div className="flex items-baseline justify-between mb-4">
          <div>
            <span className="text-[11px] text-[#64748B] block">Starting from</span>
            {pkg.priceQuad ? (
              <div className="flex items-baseline gap-1">
                <span className="text-xl sm:text-2xl font-bold font-mono tabular-nums text-[#082B49]">
                  ₹{pkg.priceQuad.toLocaleString('en-IN')}
                </span>
                <span className="text-[11px] text-[#64748B]">/ person</span>
              </div>
            ) : (
              <span className="text-sm font-semibold text-[#082B49]">Contact for pricing</span>
            )}
          </div>

          <span className="text-[10px] text-[#64748B] text-right">
            Quad sharing basis*
          </span>
        </div>

        {/* CTAs */}
        <div className="grid grid-cols-2 gap-2">
          <button
            type="button"
            onClick={() => onViewDetails(pkg)}
            className="w-full inline-flex items-center justify-center gap-1.5 px-3 py-2.5 text-xs font-semibold text-[#082B49] bg-[#FAF8F3] hover:bg-[#F1E9DA] border border-[#082B49]/15 rounded-xl transition-colors duration-150"
          >
            <span>View Details</span>
            <ArrowRight className="w-3.5 h-3.5 text-[#082B49]" />
          </button>

          <a
            href={whatsappUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="w-full inline-flex items-center justify-center gap-1.5 px-3 py-2.5 text-xs font-semibold text-white bg-[#082B49] hover:bg-[#061e33] rounded-xl transition-colors duration-150"
          >
            <MessageCircle className="w-3.5 h-3.5 text-[#C9A45C]" />
            <span>WhatsApp</span>
          </a>
        </div>
      </div>
    </div>
  );
};
