import React, { useState } from 'react';
import { HOTELS_DATA, HotelEntry } from '../data/hotels';
import { Building, MapPin, Bus, Footprints, ArrowRight } from 'lucide-react';
import makkahHotelImg from '../assets/images/makkah_hotel_luxury_1792051323994.jpg';
import madinahMosqueImg from '../assets/images/madinah_masjid_an_nabawi_1792051325182.jpg';

interface HotelSectionProps {
  onSelectTier: (tierName: string) => void;
}

export const HotelSection: React.FC<HotelSectionProps> = ({ onSelectTier }) => {
  const [activeCityTab, setActiveCityTab] = useState<'Makkah' | 'Madinah'>('Makkah');
  const [activeTierFilter, setActiveTierFilter] = useState<'All' | 'Budget' | 'Bronze' | 'Silver' | 'Gold' | 'Diamond'>('All');

  const filteredHotels = HOTELS_DATA.filter((hotel) => {
    if (hotel.city !== activeCityTab) return false;
    if (activeTierFilter !== 'All' && hotel.tier !== activeTierFilter) return false;
    return true;
  });

  return (
    <section id="hotels" className="py-14 sm:py-20 bg-[#FAF8F3] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-10 sm:mb-12">
          <div className="inline-flex items-center gap-2 mb-2 text-xs font-semibold text-[#0F4C4C] uppercase tracking-wider">
            <Building className="w-4 h-4 text-[#C9A45C]" />
            <span>Verified Pilgrimage Stays</span>
          </div>
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-serif font-bold text-[#082B49] tracking-tight">
            Hotels in Makkah & Madinah
          </h2>
          <p className="mt-3 text-sm sm:text-base text-[#64748B]">
            Transparent pedestrian distances to the holy courtyards. Every hotel is selected for cleanliness, comfort, and direct accessibility.
          </p>
        </div>

        {/* Visual City Atmosphere Spotlights */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-10">
          {/* Makkah Card */}
          <div
            onClick={() => setActiveCityTab('Makkah')}
            className={`relative rounded-2xl overflow-hidden cursor-pointer transition-all duration-300 border ${
              activeCityTab === 'Makkah'
                ? 'ring-2 ring-[#082B49] border-[#082B49] shadow-md'
                : 'border-[#082B49]/10 opacity-80 hover:opacity-100'
            }`}
          >
            <div className="h-44 sm:h-52 w-full relative">
              <img
                src={makkahHotelImg}
                alt="Hotel room view facing Masjid al-Haram in Makkah"
                referrerPolicy="no-referrer"
                loading="lazy"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#082B49]/90 via-[#082B49]/40 to-transparent" />
              <div className="absolute bottom-4 left-4 right-4 text-white">
                <span className="text-[10px] font-semibold tracking-wider uppercase text-[#C9A45C]">
                  Holy City of Makkah
                </span>
                <h3 className="text-xl font-serif font-bold">Makkah al-Mukarramah Hotels</h3>
                <p className="text-xs text-white/80 mt-0.5">
                  Options from 0m Clock Tower luxury to convenient 24/7 shuttle towers
                </p>
              </div>
            </div>
          </div>

          {/* Madinah Card */}
          <div
            onClick={() => setActiveCityTab('Madinah')}
            className={`relative rounded-2xl overflow-hidden cursor-pointer transition-all duration-300 border ${
              activeCityTab === 'Madinah'
                ? 'ring-2 ring-[#082B49] border-[#082B49] shadow-md'
                : 'border-[#082B49]/10 opacity-80 hover:opacity-100'
            }`}
          >
            <div className="h-44 sm:h-52 w-full relative">
              <img
                src={madinahMosqueImg}
                alt="Masjid an-Nabawi Prophet's Mosque courtyard in Madinah"
                referrerPolicy="no-referrer"
                loading="lazy"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#082B49]/90 via-[#082B49]/40 to-transparent" />
              <div className="absolute bottom-4 left-4 right-4 text-white">
                <span className="text-[10px] font-semibold tracking-wider uppercase text-[#C9A45C]">
                  City of the Prophet
                </span>
                <h3 className="text-xl font-serif font-bold">Madinah al-Munawwarah Hotels</h3>
                <p className="text-xs text-white/80 mt-0.5">
                  Central Markazia stays situated 50m to 500m from prayer gates
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* City Switcher & Tier Filter Controls */}
        <div className="bg-white rounded-2xl border border-[#082B49]/10 p-4 sm:p-5 mb-8 flex flex-col md:flex-row items-center justify-between gap-4">
          {/* City Tabs */}
          <div className="flex items-center gap-1.5 p-1 bg-[#FAF8F3] rounded-xl border border-[#082B49]/10 w-full md:w-auto">
            <button
              type="button"
              onClick={() => setActiveCityTab('Makkah')}
              className={`flex-1 md:flex-initial px-5 py-2 text-xs font-semibold rounded-lg transition-colors ${
                activeCityTab === 'Makkah'
                  ? 'bg-[#082B49] text-white shadow-xs'
                  : 'text-[#1F2933] hover:text-[#082B49]'
              }`}
            >
              Makkah Hotels ({HOTELS_DATA.filter((h) => h.city === 'Makkah').length})
            </button>
            <button
              type="button"
              onClick={() => setActiveCityTab('Madinah')}
              className={`flex-1 md:flex-initial px-5 py-2 text-xs font-semibold rounded-lg transition-colors ${
                activeCityTab === 'Madinah'
                  ? 'bg-[#082B49] text-white shadow-xs'
                  : 'text-[#1F2933] hover:text-[#082B49]'
              }`}
            >
              Madinah Hotels ({HOTELS_DATA.filter((h) => h.city === 'Madinah').length})
            </button>
          </div>

          {/* Tier Segmented Filter */}
          <div className="flex items-center gap-1 overflow-x-auto w-full md:w-auto pb-1 md:pb-0">
            {(['All', 'Budget', 'Bronze', 'Silver', 'Gold', 'Diamond'] as const).map((tier) => (
              <button
                key={tier}
                type="button"
                onClick={() => setActiveTierFilter(tier)}
                className={`px-3 py-1.5 text-xs font-medium rounded-lg whitespace-nowrap transition-colors ${
                  activeTierFilter === tier
                    ? 'bg-[#082B49] text-white'
                    : 'bg-[#FAF8F3] text-[#1F2933] hover:bg-[#F1E9DA] border border-[#082B49]/8'
                }`}
              >
                {tier}
              </button>
            ))}
          </div>
        </div>

        {/* Hotels Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {filteredHotels.map((hotel) => (
            <div
              key={hotel.id}
              className="bg-white rounded-2xl border border-[#082B49]/10 p-5 flex flex-col justify-between hover:shadow-md transition-shadow"
            >
              <div>
                {/* Unboxed Metadata Header */}
                <div className="flex items-center justify-between gap-2 mb-2">
                  <span className="text-[11px] font-semibold text-[#0F4C4C] uppercase tracking-wide">
                    {hotel.city} · {hotel.tierDisplay}
                  </span>
                  <div className="flex items-center gap-1 text-xs text-[#082B49] font-medium bg-[#FAF8F3] px-2.5 py-0.5 rounded-md border border-[#082B49]/10">
                    {hotel.shuttleOrWalk === '24/7 Shuttle Bus' ? (
                      <Bus className="w-3.5 h-3.5 text-[#C9A45C]" />
                    ) : (
                      <Footprints className="w-3.5 h-3.5 text-[#0F4C4C]" />
                    )}
                    <span>{hotel.distance}</span>
                  </div>
                </div>

                {/* Hotel Name */}
                <h3 className="text-base font-serif font-bold text-[#082B49] leading-snug">
                  {hotel.name}
                </h3>

                {/* Location indicator */}
                <div className="mt-2.5 flex items-start gap-1.5 text-xs text-[#64748B]">
                  <MapPin className="w-3.5 h-3.5 text-[#C9A45C] shrink-0 mt-0.5" />
                  <span className="leading-snug">{hotel.locationIndicator}</span>
                </div>

                {/* Description */}
                <p className="mt-3 text-xs text-[#1F2933] leading-relaxed">
                  {hotel.description}
                </p>
              </div>

              {/* View Package CTA */}
              <div className="mt-5 pt-3 border-t border-[#082B49]/8">
                <button
                  type="button"
                  onClick={() => onSelectTier(hotel.relatedPackageCategory)}
                  className="w-full inline-flex items-center justify-center gap-1.5 py-2 text-xs font-semibold text-[#082B49] bg-[#FAF8F3] hover:bg-[#F1E9DA] border border-[#082B49]/10 rounded-xl transition-colors"
                >
                  <span>View Related Packages</span>
                  <ArrowRight className="w-3.5 h-3.5 text-[#082B49]" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
