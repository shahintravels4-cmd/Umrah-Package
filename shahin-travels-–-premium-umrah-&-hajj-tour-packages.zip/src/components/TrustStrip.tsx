import React from 'react';
import { Plane, Building, Bus, FileText } from 'lucide-react';

export const TrustStrip: React.FC = () => {
  const trustItems = [
    {
      icon: Plane,
      title: 'Flight Assistance',
      desc: 'Saudi Airlines direct & partner flights',
    },
    {
      icon: Building,
      title: 'Hotel Accommodation',
      desc: 'Makkah & Madinah verified stays',
    },
    {
      icon: Bus,
      title: 'Ground Transfers',
      desc: 'Air-conditioned intercity coaches',
    },
    {
      icon: FileText,
      title: 'Visa Assistance',
      desc: 'Umrah electronic visa & insurance',
    },
  ];

  return (
    <section className="bg-white border-y border-[#082B49]/8 py-6 relative z-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
          {trustItems.map((item, idx) => {
            const Icon = item.icon;
            return (
              <div
                key={idx}
                className="flex items-center gap-3.5 p-3 sm:p-4 rounded-xl bg-[#FAF8F3]/60 border border-[#082B49]/5 hover:border-[#C9A45C]/40 transition-colors duration-200"
              >
                <div className="w-10 h-10 rounded-lg bg-[#082B49]/5 flex items-center justify-center text-[#082B49] shrink-0">
                  <Icon className="w-5 h-5 text-[#0F4C4C]" />
                </div>
                <div className="min-w-0">
                  <h2 className="text-sm font-semibold text-[#082B49] truncate">
                    {item.title}
                  </h2>
                  <p className="text-xs text-[#64748B] truncate">
                    {item.desc}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
