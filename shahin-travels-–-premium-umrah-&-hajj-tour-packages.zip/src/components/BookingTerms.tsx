import React from 'react';
import { BOOKING_TERMS, BUSINESS_INFO } from '../data/business';
import { ShieldAlert, Info, AlertTriangle } from 'lucide-react';

export const BookingTerms: React.FC = () => {
  return (
    <section id="terms" className="py-14 sm:py-20 bg-[#FAF8F3] border-t border-[#082B49]/8 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-10 sm:mb-12">
          <div className="inline-flex items-center gap-2 mb-2 text-xs font-semibold text-[#0F4C4C] uppercase tracking-wider">
            <Info className="w-4 h-4 text-[#C9A45C]" />
            <span>Clear Terms & Policies</span>
          </div>
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-serif font-bold text-[#082B49] tracking-tight">
            Important Booking Information
          </h2>
          <p className="mt-3 text-sm sm:text-base text-[#64748B]">
            Transparent terms to ensure absolute clarity before confirming your pilgrimage reservation.
          </p>
        </div>

        {/* Highlight Alert Box */}
        <div className="bg-[#082B49] text-white rounded-2xl p-5 sm:p-6 mb-8 flex items-start gap-4 shadow-sm border border-[#082B49]/20">
          <AlertTriangle className="w-6 h-6 text-[#C9A45C] shrink-0 mt-0.5" />
          <div className="text-xs sm:text-sm">
            <span className="font-semibold text-[#C9A45C] block mb-1 uppercase tracking-wider text-xs">
              Pre-Payment Notice
            </span>
            <p className="text-white/90 leading-relaxed font-medium">
              "Please confirm the latest price, availability and terms with Shahin Travels before making payment."
            </p>
          </div>
        </div>

        {/* Terms Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {BOOKING_TERMS.map((term, index) => (
            <div
              key={index}
              className="bg-white rounded-2xl border border-[#082B49]/10 p-5 sm:p-6 hover:shadow-sm transition-shadow"
            >
              <div className="flex items-center gap-2.5 mb-2.5">
                <span className="w-2 h-2 rounded-full bg-[#C9A45C]" />
                <h3 className="text-sm sm:text-base font-serif font-bold text-[#082B49]">
                  {term.title}
                </h3>
              </div>
              <p className="text-xs text-[#64748B] leading-relaxed">
                {term.text}
              </p>
            </div>
          ))}
        </div>

        {/* Bottom Contact Verification Banner */}
        <div className="mt-8 text-center text-xs text-[#64748B]">
          <span>For questions regarding cancellation policies or child fares, reach us directly at </span>
          <a
            href={`mailto:${BUSINESS_INFO.email}`}
            className="font-semibold text-[#082B49] underline decoration-[#C9A45C]"
          >
            {BUSINESS_INFO.email}
          </a>
          <span> or call </span>
          <a
            href={`tel:${BUSINESS_INFO.phone}`}
            className="font-semibold text-[#082B49] underline decoration-[#C9A45C]"
          >
            {BUSINESS_INFO.phoneDisplay}
          </a>.
        </div>
      </div>
    </section>
  );
};
