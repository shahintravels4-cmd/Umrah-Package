import React from 'react';
import { ShahinLogo } from './ShahinLogo';
import { BUSINESS_INFO } from '../data/business';
import { Phone, Mail, MapPin, MessageCircle, Heart } from 'lucide-react';

export const Footer: React.FC = () => {
  const currentYear = new Date().getFullYear();

  const whatsappUrl = `https://wa.me/${BUSINESS_INFO.whatsappNumber}?text=${encodeURIComponent(
    'Assalamualaikum, I would like to enquire about your Umrah tour packages.'
  )}`;

  const quickLinks = [
    { label: 'Home', href: '#home' },
    { label: 'Umrah Packages', href: '#packages' },
    { label: 'Package Tiers', href: '#tiers' },
    { label: 'Hotels', href: '#hotels' },
    { label: 'Why Shahin Travels', href: '#why-us' },
    { label: 'Umrah Guide', href: '#guide' },
    { label: 'Booking Terms', href: '#terms' },
    { label: 'Contact', href: '#contact' },
  ];

  return (
    <footer className="bg-[#082B49] text-white pt-14 pb-8 border-t border-[#082B49]/20 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-8 pb-12 border-b border-white/10">
          {/* Col 1: Brand & Subtitle */}
          <div className="lg:col-span-5 space-y-4">
            <ShahinLogo variant="light" size="lg" />

            <p className="text-xs sm:text-sm text-white/70 max-w-sm leading-relaxed">
              Specialists in sacred Umrah & Hajj journeys, fixed group departures from Delhi and Mumbai, transparent hotel distances, and dedicated on-ground pilgrim assistance.
            </p>

            <div className="flex items-center gap-3 pt-1">
              <a
                href={whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-3.5 py-2 text-xs font-semibold text-white bg-[#0F4C4C] hover:bg-[#0c3e3e] rounded-lg transition-colors"
              >
                <MessageCircle className="w-4 h-4 text-[#C9A45C]" />
                <span>WhatsApp Enquiry</span>
              </a>

              <a
                href={`tel:${BUSINESS_INFO.phone}`}
                className="inline-flex items-center gap-2 px-3.5 py-2 text-xs font-semibold text-white bg-white/10 hover:bg-white/15 rounded-lg transition-colors"
              >
                <Phone className="w-4 h-4 text-[#C9A45C]" />
                <span>{BUSINESS_INFO.phoneDisplay}</span>
              </a>
            </div>
          </div>

          {/* Col 2: Quick Links */}
          <div className="lg:col-span-3">
            <h3 className="text-xs font-semibold uppercase tracking-widest text-[#C9A45C] mb-4">
              Quick Links
            </h3>
            <ul className="space-y-2 text-xs text-white/80">
              {quickLinks.map((item) => (
                <li key={item.label}>
                  <a
                    href={item.href}
                    className="hover:text-white hover:underline transition-colors"
                  >
                    {item.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Col 3: Direct Contact Information */}
          <div className="lg:col-span-4 space-y-3">
            <h3 className="text-xs font-semibold uppercase tracking-widest text-[#C9A45C] mb-4">
              Contact Shahin Travels
            </h3>

            <div className="space-y-2.5 text-xs text-white/80">
              <div className="flex items-center gap-2.5">
                <Phone className="w-4 h-4 text-[#C9A45C] shrink-0" />
                <a href={`tel:${BUSINESS_INFO.phone}`} className="hover:text-white font-mono">
                  {BUSINESS_INFO.phoneDisplay}
                </a>
              </div>

              <div className="flex items-center gap-2.5">
                <Mail className="w-4 h-4 text-[#C9A45C] shrink-0" />
                <a href={`mailto:${BUSINESS_INFO.email}`} className="hover:text-white">
                  {BUSINESS_INFO.email}
                </a>
              </div>

              <div className="flex items-start gap-2.5">
                <MapPin className="w-4 h-4 text-[#C9A45C] shrink-0 mt-0.5" />
                <span>{BUSINESS_INFO.address}</span>
              </div>
            </div>

            <div className="mt-4 p-3 rounded-xl bg-white/5 border border-white/10 text-[11px] text-white/70">
              <strong>Fixed Group Flights:</strong> Direct departures available from Delhi (IGI) and Mumbai (BOM) via Saudi Airlines and IndiGo.
            </div>
          </div>
        </div>

        {/* Mandatory Disclaimer from Section 18 */}
        <div className="py-6 border-b border-white/10 text-xs text-white/60 text-center sm:text-left leading-relaxed">
          <p>
            <strong>Disclaimer:</strong> {BUSINESS_INFO.disclaimer}
          </p>
        </div>

        {/* Copyright & Bottom Bar */}
        <div className="pt-6 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-white/50">
          <div>
            © {currentYear} {BUSINESS_INFO.name}. All rights reserved.
          </div>
          <div className="flex items-center gap-1 text-[11px]">
            <span>Dedicated to serving the guests of the Most Merciful</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
