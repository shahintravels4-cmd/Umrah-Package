import React, { useState, useEffect } from 'react';
import { PACKAGES } from '../data/packages';
import { BUSINESS_INFO } from '../data/business';
import { X, CheckCircle, MessageCircle, Send, User, Phone, Users, Calendar, HelpCircle } from 'lucide-react';

interface EnquiryModalProps {
  isOpen: boolean;
  onClose: () => void;
  defaultPackageName?: string;
}

export const EnquiryModal: React.FC<EnquiryModalProps> = ({
  isOpen,
  onClose,
  defaultPackageName,
}) => {
  const [fullName, setFullName] = useState('');
  const [mobileNumber, setMobileNumber] = useState('');
  const [preferredPackage, setPreferredPackage] = useState(defaultPackageName || '');
  const [preferredTravelDate, setPreferredTravelDate] = useState('');
  const [travellersCount, setTravellersCount] = useState('2');
  const [message, setMessage] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);

  useEffect(() => {
    if (defaultPackageName) {
      setPreferredPackage(defaultPackageName);
    }
  }, [defaultPackageName]);

  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
      setIsSubmitted(false);
    } else {
      document.body.style.overflow = 'unset';
    }
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [isOpen]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!fullName || !mobileNumber) return;
    setIsSubmitted(true);
  };

  const handleWhatsAppDirect = () => {
    const text = `Assalamualaikum,
Name: ${fullName || 'Not provided'}
Phone: ${mobileNumber || 'Not provided'}
Package: ${preferredPackage || 'General Umrah Enquiry'}
Preferred Date: ${preferredTravelDate || 'Flexible'}
Travellers: ${travellersCount}
Message: ${message || 'Please share available dates and pricing.'}`;

    const url = `https://wa.me/${BUSINESS_INFO.whatsappNumber}?text=${encodeURIComponent(text)}`;
    window.open(url, '_blank');
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-xs overflow-y-auto animate-fade-in"
      onClick={onClose}
      role="dialog"
      aria-modal="true"
    >
      <div
        className="relative w-full max-w-lg bg-[#FAF8F3] rounded-2xl shadow-2xl border border-[#082B49]/15 overflow-hidden text-left"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="bg-[#082B49] text-white p-6 relative">
          <button
            type="button"
            onClick={onClose}
            className="absolute top-5 right-5 p-2 rounded-full bg-white/10 hover:bg-white/20 text-white transition-colors"
            aria-label="Close enquiry modal"
          >
            <X className="w-5 h-5" />
          </button>
          <span className="text-[11px] font-semibold text-[#C9A45C] uppercase tracking-wider block mb-1">
            Quick Assistance
          </span>
          <h2 className="text-xl sm:text-2xl font-serif font-bold text-white">
            Umrah Package Enquiry
          </h2>
          <p className="text-xs text-white/80 mt-1">
            Our Umrah booking specialists will connect with you via phone or WhatsApp promptly.
          </p>
        </div>

        {/* Content */}
        <div className="p-6">
          {isSubmitted ? (
            <div className="text-center py-8 space-y-4">
              <div className="w-14 h-14 rounded-full bg-emerald-50 text-emerald-600 flex items-center justify-center mx-auto border border-emerald-200">
                <CheckCircle className="w-8 h-8" />
              </div>
              <h3 className="text-xl font-serif font-bold text-[#082B49]">
                Jazakallah Khair! Enquiry Received
              </h3>
              <p className="text-xs text-[#64748B] max-w-sm mx-auto leading-relaxed">
                Thank you, <strong>{fullName}</strong>. We have received your request for{' '}
                <strong>{preferredPackage || 'Umrah Tour'}</strong>. A dedicated Shahin Travels representative will call or message you on{' '}
                <strong>{mobileNumber}</strong> shortly.
              </p>
              <div className="pt-4 flex flex-col sm:flex-row items-center justify-center gap-3">
                <button
                  type="button"
                  onClick={handleWhatsAppDirect}
                  className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-5 py-2.5 text-xs font-semibold text-white bg-[#0F4C4C] hover:bg-[#082B49] rounded-xl transition-colors"
                >
                  <MessageCircle className="w-4 h-4 text-[#C9A45C]" />
                  <span>Open directly in WhatsApp</span>
                </button>
                <button
                  type="button"
                  onClick={onClose}
                  className="w-full sm:w-auto px-4 py-2.5 text-xs font-medium text-[#64748B] hover:text-[#082B49]"
                >
                  Close Window
                </button>
              </div>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              {/* Full Name */}
              <div>
                <label className="block text-xs font-semibold text-[#082B49] mb-1">
                  Full Name <span className="text-red-500">*</span>
                </label>
                <div className="relative">
                  <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#64748B]" />
                  <input
                    type="text"
                    required
                    placeholder="Enter your full name"
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    className="w-full pl-9 pr-3 py-2 text-xs sm:text-sm bg-white border border-[#082B49]/15 rounded-xl focus:outline-none focus:border-[#082B49]"
                  />
                </div>
              </div>

              {/* Mobile Number */}
              <div>
                <label className="block text-xs font-semibold text-[#082B49] mb-1">
                  Mobile Number (WhatsApp Preferred) <span className="text-red-500">*</span>
                </label>
                <div className="relative">
                  <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#64748B]" />
                  <input
                    type="tel"
                    required
                    placeholder="e.g. 9911446919"
                    value={mobileNumber}
                    onChange={(e) => setMobileNumber(e.target.value)}
                    className="w-full pl-9 pr-3 py-2 text-xs sm:text-sm bg-white border border-[#082B49]/15 rounded-xl focus:outline-none focus:border-[#082B49]"
                  />
                </div>
              </div>

              {/* Preferred Package */}
              <div>
                <label className="block text-xs font-semibold text-[#082B49] mb-1">
                  Preferred Package
                </label>
                <select
                  value={preferredPackage}
                  onChange={(e) => setPreferredPackage(e.target.value)}
                  className="w-full px-3 py-2 text-xs sm:text-sm bg-white border border-[#082B49]/15 rounded-xl focus:outline-none focus:border-[#082B49]"
                >
                  <option value="">-- Select Preferred Package (Optional) --</option>
                  {PACKAGES.map((pkg) => (
                    <option key={pkg.id} value={pkg.name}>
                      {pkg.name} ({pkg.departureCity} - {pkg.tierDisplay})
                    </option>
                  ))}
                  <option value="Custom Group / Private Umrah">Custom Group / Private Umrah</option>
                </select>
              </div>

              {/* Travel Date & Travellers Count */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-[#082B49] mb-1">
                    Preferred Travel Month/Date
                  </label>
                  <div className="relative">
                    <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#64748B]" />
                    <input
                      type="text"
                      placeholder="e.g. Next month / Flexible"
                      value={preferredTravelDate}
                      onChange={(e) => setPreferredTravelDate(e.target.value)}
                      className="w-full pl-9 pr-3 py-2 text-xs sm:text-sm bg-white border border-[#082B49]/15 rounded-xl focus:outline-none focus:border-[#082B49]"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#082B49] mb-1">
                    Number of Travellers
                  </label>
                  <div className="relative">
                    <Users className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#64748B]" />
                    <select
                      value={travellersCount}
                      onChange={(e) => setTravellersCount(e.target.value)}
                      className="w-full pl-9 pr-3 py-2 text-xs sm:text-sm bg-white border border-[#082B49]/15 rounded-xl focus:outline-none focus:border-[#082B49]"
                    >
                      <option value="1">1 Person</option>
                      <option value="2">2 Persons (Couple / Sharing)</option>
                      <option value="3">3 Persons</option>
                      <option value="4">4 Persons (1 Quad Room)</option>
                      <option value="5-8">5 to 8 Persons (Family Group)</option>
                      <option value="9+">9+ Persons (Large Group)</option>
                    </select>
                  </div>
                </div>
              </div>

              {/* Message */}
              <div>
                <label className="block text-xs font-semibold text-[#082B49] mb-1">
                  Message / Special Requirements
                </label>
                <textarea
                  rows={2}
                  placeholder="Need wheelchair assistance, specific room preferences, or flight dates..."
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  className="w-full px-3 py-2 text-xs sm:text-sm bg-white border border-[#082B49]/15 rounded-xl focus:outline-none focus:border-[#082B49] resize-none"
                />
              </div>

              {/* Action Buttons */}
              <div className="pt-2 flex flex-col sm:flex-row gap-2.5">
                <button
                  type="submit"
                  className="w-full sm:flex-1 py-3 text-xs font-semibold text-white bg-[#082B49] hover:bg-[#061e33] rounded-xl transition-all shadow-sm flex items-center justify-center gap-2"
                >
                  <Send className="w-3.5 h-3.5 text-[#C9A45C]" />
                  <span>Send Enquiry</span>
                </button>

                <button
                  type="button"
                  onClick={handleWhatsAppDirect}
                  className="w-full sm:flex-1 py-3 text-xs font-semibold text-[#082B49] bg-white border border-[#082B49]/20 hover:bg-[#F1E9DA] rounded-xl transition-all flex items-center justify-center gap-2"
                >
                  <MessageCircle className="w-3.5 h-3.5 text-[#0F4C4C]" />
                  <span>WhatsApp Instead</span>
                </button>
              </div>

              <div className="text-center">
                <span className="text-[10px] text-[#64748B]">
                  We respect your privacy. No spam or unsolicited calls.
                </span>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
