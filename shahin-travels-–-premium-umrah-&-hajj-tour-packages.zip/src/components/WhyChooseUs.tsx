import React from 'react';
import { TRUST_POINTS, BUSINESS_INFO } from '../data/business';
import { ShieldCheck, Building, Plane, FileCheck, Bus, Headphones, Heart } from 'lucide-react';

export const WhyChooseUs: React.FC = () => {
  const iconMap: Record<string, React.ElementType> = {
    ShieldCheck,
    Building,
    Plane,
    FileCheck,
    Bus,
    Headphones,
  };

  return (
    <section id="why-us" className="py-14 sm:py-20 bg-white border-t border-[#082B49]/8 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-12 sm:mb-16">
          <div className="inline-flex items-center gap-2 mb-2 text-xs font-semibold text-[#0F4C4C] uppercase tracking-wider">
            <Heart className="w-4 h-4 text-[#C9A45C]" />
            <span>Dedicated Service & Pilgrim Care</span>
          </div>
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-serif font-bold text-[#082B49] tracking-tight">
            Why Choose Shahin Travels
          </h2>
          <p className="mt-3 text-sm sm:text-base text-[#64748B]">
            We approach every Umrah pilgrimage as a sacred trust, providing authentic guidance, verified hotels, and dependable ground coordination.
          </p>
        </div>

        {/* 6 Trust Points Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {TRUST_POINTS.map((point, index) => {
            const IconComponent = iconMap[point.icon] || ShieldCheck;
            return (
              <div
                key={index}
                className="bg-[#FAF8F3]/60 rounded-2xl border border-[#082B49]/10 p-6 hover:border-[#C9A45C]/50 hover:bg-white hover:shadow-md transition-all duration-200"
              >
                <div className="w-12 h-12 rounded-xl bg-white border border-[#082B49]/10 flex items-center justify-center text-[#082B49] mb-4 shadow-xs">
                  <IconComponent className="w-6 h-6 text-[#0F4C4C]" />
                </div>
                <h3 className="text-base font-serif font-bold text-[#082B49]">
                  {point.title}
                </h3>
                <p className="mt-2 text-xs sm:text-sm text-[#64748B] leading-relaxed">
                  {point.description}
                </p>
              </div>
            );
          })}
        </div>

        {/* Direct Contact Banner */}
        <div className="mt-12 p-6 sm:p-8 rounded-2xl bg-[#082B49] text-white flex flex-col sm:flex-row items-center justify-between gap-6 shadow-lg">
          <div>
            <span className="text-xs font-semibold text-[#C9A45C] uppercase tracking-wider block mb-1">
              Personalized Assistance
            </span>
            <h4 className="text-xl sm:text-2xl font-serif font-bold">
              Have questions regarding family or elder bookings?
            </h4>
            <p className="text-xs sm:text-sm text-white/80 mt-1 max-w-xl">
              Our travel consultants provide honest guidance regarding wheelchair accessibility, floor levels, and hotel distances.
            </p>
          </div>

          <a
            href={`tel:${BUSINESS_INFO.phone}`}
            className="shrink-0 px-6 py-3 text-xs sm:text-sm font-semibold text-[#082B49] bg-white hover:bg-[#F1E9DA] rounded-xl transition-colors shadow-sm whitespace-nowrap"
          >
            Call {BUSINESS_INFO.phoneDisplay}
          </a>
        </div>
      </div>
    </section>
  );
};
