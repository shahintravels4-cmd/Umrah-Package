import React, { useEffect } from 'react';
import { UmrahPackage } from '../data/packages';
import { BUSINESS_INFO } from '../data/business';
import { X, Check, Plane, Calendar, MapPin, Building, Bus, ShieldCheck, MessageCircle, AlertCircle } from 'lucide-react';

interface PackageDetailModalProps {
  pkg: UmrahPackage | null;
  onClose: () => void;
  onOpenEnquiry: (packageName: string) => void;
}

export const PackageDetailModal: React.FC<PackageDetailModalProps> = ({
  pkg,
  onClose,
  onOpenEnquiry,
}) => {
  // Prevent body scroll when modal is open
  useEffect(() => {
    if (pkg) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [pkg]);

  if (!pkg) return null;

  const whatsappMessage = `Assalamualaikum, I am interested in the ${pkg.name} Umrah package. Please share complete details.`;
  const whatsappUrl = `https://wa.me/${BUSINESS_INFO.whatsappNumber}?text=${encodeURIComponent(
    whatsappMessage
  )}`;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 md:p-6 bg-black/60 backdrop-blur-xs overflow-y-auto animate-fade-in"
      onClick={onClose}
      role="dialog"
      aria-modal="true"
      aria-labelledby="modal-package-title"
    >
      <div
        className="relative w-full max-w-3xl bg-[#FAF8F3] rounded-2xl sm:rounded-3xl shadow-2xl border border-[#082B49]/15 overflow-hidden my-6 text-left"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Header */}
        <div className="bg-[#082B49] text-white p-6 sm:p-8 relative">
          {/* Close button */}
          <button
            type="button"
            onClick={onClose}
            className="absolute top-5 right-5 p-2 rounded-full bg-white/10 hover:bg-white/20 text-white transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-[#C9A45C]"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="flex flex-wrap items-center gap-2 text-xs text-[#C9A45C] font-semibold uppercase tracking-wider mb-2">
            <span>{pkg.departureCity} Departure</span>
            <span aria-hidden="true">·</span>
            <span>{pkg.duration}</span>
            <span aria-hidden="true">·</span>
            <span>{pkg.tierDisplay}</span>
          </div>

          <h2 id="modal-package-title" className="text-2xl sm:text-3xl font-serif font-bold text-white leading-tight">
            {pkg.name}
          </h2>

          {/* Quick Schedule Strip */}
          <div className="mt-4 pt-4 border-t border-white/15 grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs text-white/90">
            <div className="flex items-center gap-2">
              <Plane className="w-4 h-4 text-[#C9A45C] shrink-0" />
              <span>
                <strong>Airline:</strong> {pkg.airlineDisplay}
              </span>
            </div>
            <div className="flex items-center gap-2">
              <Calendar className="w-4 h-4 text-[#C9A45C] shrink-0" />
              <span>
                <strong>Departures:</strong> {pkg.departureDates.join(' | ')}
              </span>
            </div>
          </div>
        </div>

        {/* Modal Scrollable Body */}
        <div className="p-6 sm:p-8 space-y-6 max-h-[60vh] overflow-y-auto">
          {/* Section: Stays Split */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {/* Makkah Stay */}
            <div className="bg-white rounded-xl p-5 border border-[#082B49]/10 shadow-xs">
              <div className="flex items-center justify-between pb-3 border-b border-[#082B49]/8 mb-3">
                <div className="flex items-center gap-2">
                  <Building className="w-4 h-4 text-[#082B49]" />
                  <h3 className="text-sm font-serif font-bold text-[#082B49] uppercase tracking-wide">
                    Makkah Stay
                  </h3>
                </div>
                <span className="text-xs font-semibold text-[#0F4C4C] bg-[#FAF8F3] px-2 py-0.5 rounded border border-[#082B49]/10">
                  {pkg.makkahDistance}
                </span>
              </div>

              <div className="space-y-2 text-xs">
                <div>
                  <span className="text-[#64748B] block text-[11px]">Hotel Accommodation:</span>
                  <span className="font-semibold text-[#1F2933] text-sm">{pkg.makkahHotel}</span>
                </div>
                <div>
                  <span className="text-[#64748B] block text-[11px]">Transport & Access:</span>
                  <p className="text-[#1F2933] leading-relaxed">{pkg.makkahTransport}</p>
                </div>
              </div>
            </div>

            {/* Madinah Stay */}
            <div className="bg-white rounded-xl p-5 border border-[#082B49]/10 shadow-xs">
              <div className="flex items-center justify-between pb-3 border-b border-[#082B49]/8 mb-3">
                <div className="flex items-center gap-2">
                  <Building className="w-4 h-4 text-[#082B49]" />
                  <h3 className="text-sm font-serif font-bold text-[#082B49] uppercase tracking-wide">
                    Madinah Stay
                  </h3>
                </div>
                <span className="text-xs font-semibold text-[#0F4C4C] bg-[#FAF8F3] px-2 py-0.5 rounded border border-[#082B49]/10">
                  {pkg.madinahDistance}
                </span>
              </div>

              <div className="space-y-2 text-xs">
                <div>
                  <span className="text-[#64748B] block text-[11px]">Hotel Accommodation:</span>
                  <span className="font-semibold text-[#1F2933] text-sm">{pkg.madinahHotel}</span>
                </div>
                <div>
                  <span className="text-[#64748B] block text-[11px]">Walking & Access:</span>
                  <p className="text-[#1F2933] leading-relaxed">{pkg.madinahTransport}</p>
                </div>
              </div>
            </div>
          </div>

          {/* Section: Package Inclusions */}
          <div className="bg-white rounded-xl p-5 sm:p-6 border border-[#082B49]/10 shadow-xs">
            <h3 className="text-sm font-serif font-bold text-[#082B49] uppercase tracking-wide mb-3 flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-[#0F4C4C]" />
              <span>Package Includes</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-xs text-[#1F2933]">
              {pkg.inclusions.map((inc, i) => (
                <div key={i} className="flex items-start gap-2.5">
                  <Check className="w-4 h-4 text-[#0F4C4C] shrink-0 mt-0.5" />
                  <span>{inc}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Section: Pricing Breakdown & Notes */}
          <div className="bg-[#F1E9DA]/60 rounded-xl p-5 border border-[#082B49]/10">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <span className="text-[11px] font-semibold text-[#0F4C4C] uppercase tracking-wider block">
                  Package Pricing (Per Person)
                </span>
                <div className="flex flex-wrap items-baseline gap-3 mt-1">
                  {pkg.priceQuad && (
                    <div className="text-xs">
                      <span className="text-[#64748B]">Quad: </span>
                      <strong className="text-lg sm:text-xl font-bold font-mono tabular-nums text-[#082B49]">
                        ₹{pkg.priceQuad.toLocaleString('en-IN')}
                      </strong>
                    </div>
                  )}
                  {pkg.priceTriple && (
                    <div className="text-xs">
                      <span className="text-[#64748B]">Triple: </span>
                      <strong className="text-base sm:text-lg font-bold font-mono tabular-nums text-[#082B49]">
                        ₹{pkg.priceTriple.toLocaleString('en-IN')}
                      </strong>
                    </div>
                  )}
                  {pkg.priceDouble && (
                    <div className="text-xs">
                      <span className="text-[#64748B]">Twin: </span>
                      <strong className="text-base sm:text-lg font-bold font-mono tabular-nums text-[#082B49]">
                        ₹{pkg.priceDouble.toLocaleString('en-IN')}
                      </strong>
                    </div>
                  )}
                </div>
              </div>

              <div className="sm:text-right">
                <span className="text-[11px] text-[#64748B] block">Available Seats / Booking:</span>
                <span className="text-xs font-semibold text-[#082B49]">Token Deposit: ₹40,000 / Person</span>
              </div>
            </div>

            {/* Price Clarification Notice */}
            <div className="mt-4 pt-3 border-t border-[#082B49]/10 flex items-start gap-2 text-[11px] text-[#64748B]">
              <AlertCircle className="w-3.5 h-3.5 text-[#C9A45C] shrink-0 mt-0.5" />
              <span>
                <strong>Important Notice:</strong> Prices are subject to airfare, hotel availability and applicable changes. Contact Shahin Travels for current dates and exact booking quotes.
              </span>
            </div>
          </div>
        </div>

        {/* Modal Footer / CTAs */}
        <div className="p-5 sm:p-6 bg-white border-t border-[#082B49]/10 flex flex-col sm:flex-row items-center justify-between gap-3">
          <button
            type="button"
            onClick={onClose}
            className="w-full sm:w-auto px-5 py-2.5 text-xs font-medium text-[#64748B] hover:text-[#082B49] transition-colors"
          >
            Back to Packages
          </button>

          <div className="flex items-center gap-3 w-full sm:w-auto">
            <button
              type="button"
              onClick={() => {
                onClose();
                onOpenEnquiry(pkg.name);
              }}
              className="w-full sm:w-auto px-5 py-2.5 text-xs font-semibold text-[#082B49] bg-[#FAF8F3] hover:bg-[#F1E9DA] border border-[#082B49]/15 rounded-xl transition-colors whitespace-nowrap"
            >
              Send Form Enquiry
            </button>

            <a
              href={whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-2.5 text-xs font-semibold text-white bg-[#082B49] hover:bg-[#061e33] rounded-xl transition-all shadow-sm whitespace-nowrap"
            >
              <MessageCircle className="w-4 h-4 text-[#C9A45C]" />
              <span>Enquire on WhatsApp</span>
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};
