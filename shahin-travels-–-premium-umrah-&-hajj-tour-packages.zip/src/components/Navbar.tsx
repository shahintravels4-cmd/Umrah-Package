import React, { useState, useEffect } from 'react';
import { ShahinLogo } from './ShahinLogo';
import { BUSINESS_INFO } from '../data/business';
import { Menu, X, MessageCircle, Phone } from 'lucide-react';

interface NavbarProps {
  onOpenEnquiry: (packageName?: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onOpenEnquiry }) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { label: 'Home', href: '#home' },
    { label: 'Umrah Packages', href: '#packages' },
    { label: 'Package Tiers', href: '#tiers' },
    { label: 'Hotels', href: '#hotels' },
    { label: 'Why Shahin Travels', href: '#why-us' },
    { label: 'Umrah Guide', href: '#guide' },
    { label: 'Contact', href: '#contact' },
  ];

  const handleLinkClick = (href: string) => {
    setMobileMenuOpen(false);
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const whatsappUrl = `https://wa.me/${BUSINESS_INFO.whatsappNumber}?text=${encodeURIComponent(
    'Assalamualaikum, I would like to enquire about your Umrah tour packages.'
  )}`;

  return (
    <>
      <header
        className={`sticky top-0 z-40 w-full transition-all duration-300 ${
          isScrolled
            ? 'bg-[#FAF8F3]/95 backdrop-blur-md shadow-sm border-b border-[#082B49]/10 py-3'
            : 'bg-[#FAF8F3] border-b border-[#082B49]/5 py-4'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between gap-6">
            {/* Zone 1: Brand Zone */}
            <a
              href="#home"
              onClick={(e) => {
                e.preventDefault();
                handleLinkClick('#home');
              }}
              className="shrink-0 flex items-center focus:outline-none focus-visible:ring-2 focus-visible:ring-[#C9A45C] rounded-lg"
              aria-label="Shahin Travels Home"
            >
              <ShahinLogo variant="dark" size="md" />
            </a>

            {/* Zone 2: Navigation Links */}
            <nav className="hidden xl:flex items-center gap-7 text-sm font-medium text-[#1F2933]">
              {navLinks.map((link) => (
                <a
                  key={link.label}
                  href={link.href}
                  onClick={(e) => {
                    e.preventDefault();
                    handleLinkClick(link.href);
                  }}
                  className="whitespace-nowrap transition-colors duration-150 hover:text-[#082B49] relative py-1 after:absolute after:bottom-0 after:left-0 after:w-0 after:h-[2px] after:bg-[#C9A45C] hover:after:w-full after:transition-all after:duration-200"
                >
                  {link.label}
                </a>
              ))}
            </nav>

            {/* Zone 3: Primary Action & Quick CTAs */}
            <div className="hidden sm:flex items-center gap-3 shrink-0">
              <a
                href={whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-3.5 py-2 text-xs font-semibold text-[#082B49] bg-white border border-[#082B49]/15 rounded-lg hover:border-[#082B49]/30 hover:bg-[#F1E9DA]/50 transition-colors duration-200 whitespace-nowrap shadow-xs"
                title="Chat with us on WhatsApp"
              >
                <MessageCircle className="w-4 h-4 text-[#0F4C4C]" />
                <span>WhatsApp</span>
              </a>

              <button
                type="button"
                onClick={() => onOpenEnquiry()}
                className="inline-flex items-center justify-center px-4 py-2 text-xs font-semibold text-white bg-[#082B49] rounded-lg hover:bg-[#061e33] active:scale-[0.98] transition-all duration-200 whitespace-nowrap shadow-sm hover:shadow"
              >
                Enquire Now
              </button>
            </div>

            {/* Mobile Hamburger Button */}
            <div className="flex xl:hidden items-center gap-2">
              <a
                href={whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="p-2 text-[#082B49] bg-white border border-[#082B49]/10 rounded-lg hover:bg-[#F1E9DA]"
                aria-label="WhatsApp"
              >
                <MessageCircle className="w-5 h-5 text-[#0F4C4C]" />
              </a>

              <button
                type="button"
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="p-2 text-[#082B49] hover:bg-[#F1E9DA] rounded-lg focus:outline-none focus-visible:ring-2 focus-visible:ring-[#C9A45C]"
                aria-label={mobileMenuOpen ? 'Close Menu' : 'Open Menu'}
                aria-expanded={mobileMenuOpen}
              >
                {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Mobile Slide-down Drawer Navigation */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 top-[65px] z-30 bg-black/40 backdrop-blur-xs xl:hidden animate-fade-in">
          <div className="bg-[#FAF8F3] border-b border-[#082B49]/10 px-6 py-6 max-h-[calc(100vh-65px)] overflow-y-auto shadow-xl">
            <div className="mb-4 pb-4 border-b border-[#082B49]/10">
              <ShahinLogo variant="dark" size="sm" />
            </div>

            <nav className="flex flex-col gap-3">
              {navLinks.map((link) => (
                <a
                  key={link.label}
                  href={link.href}
                  onClick={(e) => {
                    e.preventDefault();
                    handleLinkClick(link.href);
                  }}
                  className="py-2.5 text-base font-medium text-[#1F2933] border-b border-[#082B49]/5 hover:text-[#082B49] active:text-[#C9A45C]"
                >
                  {link.label}
                </a>
              ))}
            </nav>

            <div className="mt-6 pt-4 border-t border-[#082B49]/10 flex flex-col gap-3">
              <button
                type="button"
                onClick={() => {
                  setMobileMenuOpen(false);
                  onOpenEnquiry();
                }}
                className="w-full py-3 text-sm font-semibold text-white bg-[#082B49] rounded-xl text-center shadow-sm"
              >
                Enquire for Package
              </button>

              <a
                href={whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full py-3 text-sm font-semibold text-[#082B49] bg-white border border-[#082B49]/20 rounded-xl text-center flex items-center justify-center gap-2"
              >
                <MessageCircle className="w-4 h-4 text-[#0F4C4C]" />
                <span>WhatsApp Us: {BUSINESS_INFO.phoneDisplay}</span>
              </a>

              <a
                href={`tel:${BUSINESS_INFO.phone}`}
                className="w-full py-2.5 text-xs text-center text-[#64748B] hover:text-[#082B49] flex items-center justify-center gap-1.5"
              >
                <Phone className="w-3.5 h-3.5" />
                <span>Call {BUSINESS_INFO.phoneDisplay}</span>
              </a>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
