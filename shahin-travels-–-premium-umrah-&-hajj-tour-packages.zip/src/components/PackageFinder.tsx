import React, { useState, useMemo } from 'react';
import { PACKAGES, UmrahPackage } from '../data/packages';
import { PackageCard } from './PackageCard';
import { Filter, RotateCcw, Search, Compass } from 'lucide-react';

interface PackageFinderProps {
  onViewDetails: (pkg: UmrahPackage) => void;
  onEnquireNow: (pkg: UmrahPackage) => void;
  initialCategory?: string;
}

export const PackageFinder: React.FC<PackageFinderProps> = ({
  onViewDetails,
  onEnquireNow,
  initialCategory,
}) => {
  const [cityFilter, setCityFilter] = useState<'All' | 'Delhi' | 'Mumbai'>('All');
  const [airlineFilter, setAirlineFilter] = useState<'All' | 'Saudi Airlines' | 'IndiGo' | 'LCC'>('All');
  const [durationFilter, setDurationFilter] = useState<'All' | '14 Nights' | '15 Nights' | '20 Days'>('All');
  const [categoryFilter, setCategoryFilter] = useState<string>(initialCategory || 'All');
  const [searchQuery, setSearchQuery] = useState('');

  // Update category if parent passes a trigger
  React.useEffect(() => {
    if (initialCategory) {
      setCategoryFilter(initialCategory);
    }
  }, [initialCategory]);

  const filteredPackages = useMemo(() => {
    return PACKAGES.filter((pkg) => {
      // City filter
      if (cityFilter !== 'All' && pkg.departureCity !== cityFilter) return false;

      // Airline filter
      if (airlineFilter !== 'All' && pkg.airline !== airlineFilter) return false;

      // Duration filter
      if (durationFilter !== 'All' && pkg.duration !== durationFilter) return false;

      // Category filter
      if (categoryFilter !== 'All') {
        if (categoryFilter === 'Diamond' && pkg.category !== 'Diamond') return false;
        if (categoryFilter !== 'Diamond' && pkg.category !== categoryFilter) return false;
      }

      // Search query (name, hotel, airline)
      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase();
        const matchesName = pkg.name.toLowerCase().includes(query);
        const matchesMakkah = pkg.makkahHotel.toLowerCase().includes(query);
        const matchesMadinah = pkg.madinahHotel.toLowerCase().includes(query);
        const matchesAirline = pkg.airlineDisplay.toLowerCase().includes(query);
        if (!matchesName && !matchesMakkah && !matchesMadinah && !matchesAirline) return false;
      }

      return true;
    });
  }, [cityFilter, airlineFilter, durationFilter, categoryFilter, searchQuery]);

  const isFiltered =
    cityFilter !== 'All' ||
    airlineFilter !== 'All' ||
    durationFilter !== 'All' ||
    categoryFilter !== 'All' ||
    searchQuery !== '';

  const handleReset = () => {
    setCityFilter('All');
    setAirlineFilter('All');
    setDurationFilter('All');
    setCategoryFilter('All');
    setSearchQuery('');
  };

  return (
    <section id="packages" className="py-12 sm:py-16 bg-[#FAF8F3] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-10 sm:mb-12">
          <div className="inline-flex items-center gap-2 mb-2 text-xs font-semibold text-[#0F4C4C] uppercase tracking-wider">
            <Compass className="w-4 h-4 text-[#C9A45C]" />
            <span>Curated Pilgrimage Departures</span>
          </div>
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-serif font-bold text-[#082B49] tracking-tight">
            Find Your Umrah Package
          </h2>
          <p className="mt-3 text-sm sm:text-base text-[#64748B]">
            Filter verified packages by departure city, preferred airline, duration, or hotel tier.
          </p>
        </div>

        {/* Clean Filter Control Card */}
        <div className="bg-white rounded-2xl border border-[#082B49]/10 p-5 sm:p-6 shadow-xs mb-8">
          {/* Top Search & Active Filter Summary */}
          <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4 pb-5 border-b border-[#082B49]/8">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-[#64748B]" />
              <input
                type="text"
                placeholder="Search by package name, hotel or airline..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-2.5 text-xs sm:text-sm bg-[#FAF8F3] border border-[#082B49]/15 rounded-xl focus:outline-none focus:border-[#082B49] focus:bg-white transition-colors"
              />
            </div>

            <div className="flex items-center justify-between sm:justify-end gap-3">
              <span className="text-xs text-[#64748B] font-medium">
                Showing <strong className="text-[#082B49] font-mono tabular-nums">{filteredPackages.length}</strong> of{' '}
                <strong className="text-[#082B49] font-mono tabular-nums">{PACKAGES.length}</strong> packages
              </span>

              {isFiltered && (
                <button
                  type="button"
                  onClick={handleReset}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-[#082B49] hover:text-[#0F4C4C] bg-[#FAF8F3] hover:bg-[#F1E9DA] rounded-lg transition-colors border border-[#082B49]/10"
                >
                  <RotateCcw className="w-3 h-3 text-[#C9A45C]" />
                  <span>Reset Filters</span>
                </button>
              )}
            </div>
          </div>

          {/* Filter Categories Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5 pt-5">
            {/* Filter 1: Departure City */}
            <div>
              <label className="block text-[11px] font-semibold uppercase tracking-wider text-[#082B49] mb-2">
                Departure City
              </label>
              <div className="flex flex-wrap gap-1.5">
                {(['All', 'Delhi', 'Mumbai'] as const).map((city) => (
                  <button
                    key={city}
                    type="button"
                    onClick={() => setCityFilter(city)}
                    className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-all ${
                      cityFilter === city
                        ? 'bg-[#082B49] text-white shadow-xs'
                        : 'bg-[#FAF8F3] text-[#1F2933] hover:bg-[#F1E9DA] border border-[#082B49]/10'
                    }`}
                  >
                    {city === 'All' ? 'All Cities' : city}
                  </button>
                ))}
              </div>
            </div>

            {/* Filter 2: Airline */}
            <div>
              <label className="block text-[11px] font-semibold uppercase tracking-wider text-[#082B49] mb-2">
                Airline
              </label>
              <div className="flex flex-wrap gap-1.5">
                {(['All', 'Saudi Airlines', 'IndiGo', 'LCC'] as const).map((airline) => (
                  <button
                    key={airline}
                    type="button"
                    onClick={() => setAirlineFilter(airline)}
                    className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-all ${
                      airlineFilter === airline
                        ? 'bg-[#082B49] text-white shadow-xs'
                        : 'bg-[#FAF8F3] text-[#1F2933] hover:bg-[#F1E9DA] border border-[#082B49]/10'
                    }`}
                  >
                    {airline === 'All' ? 'All Airlines' : airline}
                  </button>
                ))}
              </div>
            </div>

            {/* Filter 3: Duration */}
            <div>
              <label className="block text-[11px] font-semibold uppercase tracking-wider text-[#082B49] mb-2">
                Duration
              </label>
              <div className="flex flex-wrap gap-1.5">
                {(['All', '14 Nights', '15 Nights', '20 Days'] as const).map((dur) => (
                  <button
                    key={dur}
                    type="button"
                    onClick={() => setDurationFilter(dur)}
                    className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-all ${
                      durationFilter === dur
                        ? 'bg-[#082B49] text-white shadow-xs'
                        : 'bg-[#FAF8F3] text-[#1F2933] hover:bg-[#F1E9DA] border border-[#082B49]/10'
                    }`}
                  >
                    {dur === 'All' ? 'All Durations' : dur}
                  </button>
                ))}
              </div>
            </div>

            {/* Filter 4: Package Tier / Category */}
            <div>
              <label className="block text-[11px] font-semibold uppercase tracking-wider text-[#082B49] mb-2">
                Package Tier
              </label>
              <div className="flex flex-wrap gap-1.5">
                {[
                  { id: 'All', label: 'All' },
                  { id: 'Budget', label: 'Budget' },
                  { id: 'Bronze', label: 'Bronze' },
                  { id: 'Silver', label: 'Silver' },
                  { id: 'Gold', label: 'Gold' },
                  { id: 'Diamond', label: 'Diamond' },
                ].map((tier) => (
                  <button
                    key={tier.id}
                    type="button"
                    onClick={() => setCategoryFilter(tier.id)}
                    className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-all ${
                      categoryFilter === tier.id
                        ? 'bg-[#082B49] text-white shadow-xs'
                        : 'bg-[#FAF8F3] text-[#1F2933] hover:bg-[#F1E9DA] border border-[#082B49]/10'
                    }`}
                  >
                    {tier.label}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Package Results Grid */}
        {filteredPackages.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredPackages.map((pkg) => (
              <PackageCard
                key={pkg.id}
                pkg={pkg}
                onViewDetails={onViewDetails}
                onEnquireNow={onEnquireNow}
              />
            ))}
          </div>
        ) : (
          <div className="text-center py-16 px-4 bg-white rounded-2xl border border-[#082B49]/10">
            <Filter className="w-10 h-10 text-[#64748B] mx-auto mb-3 opacity-60" />
            <h3 className="text-lg font-serif font-bold text-[#082B49]">No Packages Found</h3>
            <p className="mt-2 text-sm text-[#64748B] max-w-md mx-auto">
              We couldn't find any packages matching your specific filter criteria. Try resetting your filters or contact our team directly for custom departures.
            </p>
            <div className="mt-5">
              <button
                type="button"
                onClick={handleReset}
                className="px-5 py-2.5 text-xs font-semibold text-white bg-[#082B49] rounded-xl hover:bg-[#061e33] transition-colors"
              >
                Clear All Filters
              </button>
            </div>
          </div>
        )}

        {/* Live Information Disclaimer */}
        <div className="mt-8 p-4 rounded-xl bg-[#F1E9DA]/50 border border-[#082B49]/8 text-center text-xs text-[#64748B]">
          <p>
            <strong>Note on Live Rates:</strong> Package prices, seat availability, and flight schedules are subject to changes based on airline fares and hotel seasons. Please confirm current rates with Shahin Travels before final payment.
          </p>
        </div>
      </div>
    </section>
  );
};
