import React from 'react';
import { BUSINESS_INFO } from '../data/business';
import { MessageCircle, Phone, Mail, Clock, MapPin, Send } from 'lucide-react';

interface ContactSectionProps {
  onOpenEnquiry: () => void;
}

export const ContactSection: React.FC<ContactSectionProps> = ({ onOpenEnquiry }) => {
  const whatsappUrl = `https://wa.me/${BUSINESS_INFO.whatsappNumber}?text=${encodeURIComponent(
    'Assalamualaikum, I would like to speak with your team regarding Umrah package availability and pricing.'
  )}`;

  return (
    <section id="contact" className="py-16 sm:py-24 bg-white border-t border-[#082B49]/8 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-[#082B49] rounded-3xl text-white p-8 sm:p-12 lg:p-16 relative overflow-hidden shadow-xl">
          {/* Subtle geometric pattern ambient layer */}
          <div className="absolute inset-0 bg-dark-pattern opacity-40 pointer-events-none" />

          <div className="relative z-10 max-w-3xl mx-auto text-center">
            {/* Tagline */}
            <span className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-widest text-[#C9A45C] mb-3">
              <span className="w-1.5 h-1.5 rounded-full bg-[#C9A45C]" />
              <span>We Are Here to Assist Your Sacred Voyage</span>
            </span>

            {/* Headline */}
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-serif font-bold text-white tracking-tight leading-tight">
              Ready to Begin Your Umrah Journey?
            </h2>

            {/* Subtext */}
            <p className="mt-4 text-base sm:text-lg text-white/80 leading-relaxed max-w-xl mx-auto">
              Speak with our team for current package availability, pricing and booking assistance.
            </p>

            {/* Primary Action Buttons */}
            <div className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-3.5">
              {/* WhatsApp Us */}
              <a
                href={whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2.5 px-6 py-3.5 text-xs sm:text-sm font-semibold text-[#082B49] bg-white hover:bg-[#FAF8F3] rounded-xl transition-all duration-200 shadow-md hover:shadow-lg whitespace-nowrap"
              >
                <MessageCircle className="w-4 h-4 text-[#0F4C4C]" />
                <span>WhatsApp Us</span>
              </a>

              {/* Call Now */}
              <a
                href={`tel:${BUSINESS_INFO.phone}`}
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2.5 px-6 py-3.5 text-xs sm:text-sm font-semibold text-white bg-[#0F4C4C] hover:bg-[#0c3e3e] border border-white/10 rounded-xl transition-all duration-200 shadow-sm whitespace-nowrap"
              >
                <Phone className="w-4 h-4 text-[#C9A45C]" />
                <span>Call Now: {BUSINESS_INFO.phoneDisplay}</span>
              </a>

              {/* Email Us */}
              <a
                href={`mailto:${BUSINESS_INFO.email}`}
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2.5 px-6 py-3.5 text-xs sm:text-sm font-semibold text-white bg-white/10 hover:bg-white/15 border border-white/15 rounded-xl transition-all duration-200 whitespace-nowrap"
              >
                <Mail className="w-4 h-4 text-[#C9A45C]" />
                <span>Email Us</span>
              </a>
            </div>

            {/* Secondary Form Enquiry Button */}
            <div className="mt-6 pt-6 border-t border-white/10 flex items-center justify-center">
              <button
                type="button"
                onClick={onOpenEnquiry}
                className="inline-flex items-center gap-2 text-xs font-semibold text-[#C9A45C] hover:text-white transition-colors"
              >
                <Send className="w-3.5 h-3.5" />
                <span>Prefer an online form? Click here to submit your details</span>
              </button>
            </div>

            {/* Quick Contact Information Details */}
            <div className="mt-8 grid grid-cols-1 sm:grid-cols-3 gap-4 pt-8 border-t border-white/10 text-xs text-white/70">
              <div className="flex flex-col items-center">
                <span className="font-semibold text-white">Direct Phone</span>
                <span className="font-mono mt-0.5">{BUSINESS_INFO.phoneDisplay}</span>
              </div>
              <div className="flex flex-col items-center">
                <span className="font-semibold text-white">Email Inquiries</span>
                <span className="mt-0.5">{BUSINESS_INFO.email}</span>
              </div>
              <div className="flex flex-col items-center">
                <span className="font-semibold text-white">Operating Offices</span>
                <span className="mt-0.5">{BUSINESS_INFO.address}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
