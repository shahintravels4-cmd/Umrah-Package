import React from 'react';
import { TIER_EXPLANATIONS } from '../data/packages';
import { ArrowRight, Layers, MapPin, Utensils, HeartHandshake } from 'lucide-react';

interface PackageTierSectionProps {
  onSelectTier: (tierName: string) => void;
}

export const PackageTierSection: React.FC<PackageTierSectionProps> = ({ onSelectTier }) => {
  return (
    <section id="tiers" className="py-14 sm:py-20 bg-white border-t border-[#082B49]/8 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-12 sm:mb-16">
          <div className="inline-flex items-center gap-2 mb-2 text-xs font-semibold text-[#0F4C4C] uppercase tracking-wider">
            <Layers className="w-4 h-4 text-[#C9A45C]" />
            <span>Honest & Transparent Classification</span>
          </div>
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-serif font-bold text-[#082B49] tracking-tight">
            Compare Our Package Tiers
          </h2>
          <p className="mt-3 text-sm sm:text-base text-[#64748B]">
            Understand the exact walking distances, hotel styles, and catering details across each package tier.
          </p>
        </div>

        {/* Tiers Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-5">
          {TIER_EXPLANATIONS.map((t) => (
            <div
              key={t.tier}
              className={`rounded-2xl border p-5 flex flex-col justify-between transition-all duration-200 hover:shadow-md ${
                t.tier === 'Gold'
                  ? 'bg-[#FAF8F3] border-[#C9A45C]/60 ring-1 ring-[#C9A45C]/30 shadow-xs'
                  : 'bg-white border-[#082B49]/10 hover:border-[#082B49]/25'
              }`}
            >
              <div>
                {/* Header */}
                <div className="pb-3 border-b border-[#082B49]/8 mb-3">
                  <span className="text-[11px] font-semibold text-[#0F4C4C] uppercase tracking-wider block">
                    {t.tier}
                  </span>
                  <h3 className="text-base font-serif font-bold text-[#082B49] mt-0.5">
                    {t.headline}
                  </h3>
                  <div className="mt-2 text-xs text-[#64748B]">
                    Starting at{' '}
                    <strong className="text-sm font-bold font-mono tabular-nums text-[#082B49]">
                      {t.startingPrice}
                    </strong>
                  </div>
                </div>

                {/* Details */}
                <div className="space-y-3.5 text-xs text-[#1F2933]">
                  {/* Distance */}
                  <div>
                    <div className="flex items-center gap-1.5 text-[#0F4C4C] font-semibold text-[11px] mb-1">
                      <MapPin className="w-3.5 h-3.5 text-[#C9A45C] shrink-0" />
                      <span>Walking Distances:</span>
                    </div>
                    <p className="text-[11px] text-[#64748B] leading-tight">
                      <strong>Makkah:</strong> {t.makkahDistance}
                    </p>
                    <p className="text-[11px] text-[#64748B] leading-tight mt-1">
                      <strong>Madinah:</strong> {t.madinahDistance}
                    </p>
                  </div>

                  {/* Hotels */}
                  <div>
                    <span className="text-[11px] font-semibold text-[#082B49] block mb-0.5">
                      Example Hotels:
                    </span>
                    <p className="text-[11px] text-[#64748B] leading-tight">
                      {t.exampleHotels}
                    </p>
                  </div>

                  {/* Meals */}
                  <div>
                    <div className="flex items-center gap-1.5 text-[#082B49] font-semibold text-[11px] mb-0.5">
                      <Utensils className="w-3.5 h-3.5 text-[#0F4C4C] shrink-0" />
                      <span>Dining:</span>
                    </div>
                    <p className="text-[11px] text-[#64748B] leading-tight">
                      {t.meals}
                    </p>
                  </div>

                  {/* Ideal For */}
                  <div className="pt-2 border-t border-[#082B49]/5">
                    <div className="flex items-center gap-1 text-[#082B49] font-semibold text-[11px] mb-0.5">
                      <HeartHandshake className="w-3.5 h-3.5 text-[#C9A45C] shrink-0" />
                      <span>Best Suited For:</span>
                    </div>
                    <p className="text-[11px] text-[#64748B] leading-relaxed">
                      {t.idealFor}
                    </p>
                  </div>
                </div>
              </div>

              {/* View Packages CTA */}
              <div className="mt-5 pt-3 border-t border-[#082B49]/8">
                <button
                  type="button"
                  onClick={() => onSelectTier(t.tier)}
                  className={`w-full py-2.5 px-3 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors ${
                    t.tier === 'Gold'
                      ? 'bg-[#082B49] text-white hover:bg-[#061e33]'
                      : 'bg-[#FAF8F3] text-[#082B49] hover:bg-[#F1E9DA] border border-[#082B49]/10'
                  }`}
                >
                  <span>View {t.tier} Packages</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
