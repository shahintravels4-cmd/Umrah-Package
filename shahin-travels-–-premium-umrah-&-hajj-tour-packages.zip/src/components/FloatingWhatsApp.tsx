import React, { useState, useEffect } from 'react';
import { BUSINESS_INFO } from '../data/business';
import { MessageCircle, X } from 'lucide-react';

export const FloatingWhatsApp: React.FC = () => {
  const [isVisible, setIsVisible] = useState(false);
  const [hasPrompt, setHasPrompt] = useState(true);

  useEffect(() => {
    // Show after short scroll
    const handleScroll = () => {
      if (window.scrollY > 150) {
        setIsVisible(true);
      } else {
        setIsVisible(false);
      }
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const whatsappUrl = `https://wa.me/${BUSINESS_INFO.whatsappNumber}?text=${encodeURIComponent(
    'Assalamualaikum, I would like to enquire about your Umrah tour packages.'
  )}`;

  if (!isVisible) return null;

  return (
    <div className="fixed bottom-5 right-4 sm:bottom-6 sm:right-6 z-40 flex items-end flex-col gap-2 pointer-events-auto animate-fade-in">
      {/* Optional gentle prompt popup for first-time visitors */}
      {hasPrompt && (
        <div className="hidden sm:flex items-center gap-2 bg-white text-[#082B49] text-xs py-2 px-3.5 rounded-xl shadow-lg border border-[#082B49]/10 relative group">
          <span>Need quick package details? Chat with us</span>
          <button
            type="button"
            onClick={() => setHasPrompt(false)}
            className="text-[#64748B] hover:text-[#082B49] p-0.5 rounded focus:outline-none"
            aria-label="Dismiss chat prompt"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Floating Button */}
      <a
        href={whatsappUrl}
        target="_blank"
        rel="noopener noreferrer"
        className="flex items-center gap-2.5 px-4 py-3 bg-[#0F4C4C] hover:bg-[#082B49] text-white rounded-full shadow-lg hover:shadow-xl transition-all duration-200 focus:outline-none focus-visible:ring-2 focus-visible:ring-[#C9A45C] group border border-white/20 active:scale-95"
        aria-label="Chat with Shahin Travels on WhatsApp"
      >
        <MessageCircle className="w-5 h-5 text-[#C9A45C] group-hover:scale-110 transition-transform" />
        <span className="text-xs font-semibold whitespace-nowrap hidden sm:inline">
          WhatsApp Assistance
        </span>
      </a>
    </div>
  );
};
