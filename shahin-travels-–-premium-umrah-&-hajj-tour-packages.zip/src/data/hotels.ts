/**
 * Shahin Travels - Hotel Directory Data Store
 * 
 * Sourced directly from verified Umrah partner hotel properties in Makkah & Madinah.
 * Distances represent approximate pedestrian walking meters to the outer boundary of the sacred courtyards.
 */

export interface HotelEntry {
  id: string;
  name: string;
  city: "Makkah" | "Madinah";
  tier: "Budget" | "Bronze" | "Silver" | "Gold" | "Diamond";
  tierDisplay: string;
  distance: string;
  distanceNumber: number; // in meters for sorting/comparison
  locationIndicator: string; // e.g., "Ajyad Street", "Ibrahim Khalil Road", "Markazia Northern"
  shuttleOrWalk: "Direct Elevator" | "Walking Distance" | "24/7 Shuttle Bus";
  description: string;
  relatedPackageCategory: "Budget" | "Bronze" | "Silver" | "Gold" | "Diamond";
}

export const HOTELS_DATA: HotelEntry[] = [
  // =================== MAKKAH HOTELS ===================
  {
    id: "makkah-fairmont-clock-tower",
    name: "Makkah Clock Royal Tower (Fairmont / Swissôtel)",
    city: "Makkah",
    tier: "Diamond",
    tierDisplay: "Diamond / Luxury",
    distance: "0m – 50m",
    distanceNumber: 25,
    locationIndicator: "Abraj Al Bait Complex, King Abdulaziz Gate",
    shuttleOrWalk: "Direct Elevator",
    description: "Iconic landmark complex with direct private elevator access to the Holy Mosque courtyard.",
    relatedPackageCategory: "Diamond"
  },
  {
    id: "makkah-mira-ajyad",
    name: "Mira Ajyad / Elaf Ajyad Hotel",
    city: "Makkah",
    tier: "Gold",
    tierDisplay: "Gold Tier",
    distance: "200m – 250m",
    distanceNumber: 220,
    locationIndicator: "Ajyad Street, South of Haram",
    shuttleOrWalk: "Walking Distance",
    description: "Highly sought-after Ajyad location offering effortless flat walking access for elderly pilgrims.",
    relatedPackageCategory: "Gold"
  },
  {
    id: "makkah-waha-deafa",
    name: "Waha Deafa / Mather Jawar Hotel",
    city: "Makkah",
    tier: "Silver",
    tierDisplay: "Silver Tier",
    distance: "450m – 500m",
    distanceNumber: 480,
    locationIndicator: "Ajyad Al Sud / Ibrahim Khalil Road",
    shuttleOrWalk: "Walking Distance",
    description: "Well-established hospitality with comfortable rooms, elevators, and approx. 6–7 minutes walking route.",
    relatedPackageCategory: "Silver"
  },
  {
    id: "makkah-tara-ajyad",
    name: "Tara Ajyad Hotel",
    city: "Makkah",
    tier: "Silver",
    tierDisplay: "Silver Tier",
    distance: "500m",
    distanceNumber: 500,
    locationIndicator: "Ajyad Street, Makkah",
    shuttleOrWalk: "Walking Distance",
    description: "Popular family choice with nearby Indian dining options and direct pavement to the outer courtyard.",
    relatedPackageCategory: "Silver"
  },
  {
    id: "makkah-waref-al-deafa",
    name: "Waref Al Deafa / Olayan Al Khalil",
    city: "Makkah",
    tier: "Bronze",
    tierDisplay: "Bronze Tier",
    distance: "650m – 800m",
    distanceNumber: 720,
    locationIndicator: "Ibrahim Khalil Road, Makkah",
    shuttleOrWalk: "Walking Distance",
    description: "Clean, spacious economy property within walking distance along active commercial pilgrimage corridors.",
    relatedPackageCategory: "Bronze"
  },
  {
    id: "makkah-le-meridien-towers",
    name: "Le Meridien Towers / Kiswah Towers",
    city: "Makkah",
    tier: "Budget",
    tierDisplay: "Budget Tier",
    distance: "1500m – 1800m",
    distanceNumber: 1650,
    locationIndicator: "Kudai District, Makkah",
    shuttleOrWalk: "24/7 Shuttle Bus",
    description: "Modern large-scale tower properties with continuous 24/7 free shuttles dropping at Kudai / Ajyad terminal.",
    relatedPackageCategory: "Budget"
  },

  // =================== MADINAH HOTELS ===================
  {
    id: "madinah-al-aqeeq",
    name: "Al Aqeeq Madinah / Dar Al Taqwa",
    city: "Madinah",
    tier: "Diamond",
    tierDisplay: "Diamond / Luxury",
    distance: "0m – 50m",
    distanceNumber: 25,
    locationIndicator: "Northern Central Courtyard, Markazia",
    shuttleOrWalk: "Direct Elevator",
    description: "Facing the main gates of the Prophet's Mosque courtyard with premier 5-star services.",
    relatedPackageCategory: "Diamond"
  },
  {
    id: "madinah-madina-baity",
    name: "Madina Baity / One Inn Hotel",
    city: "Madinah",
    tier: "Gold",
    tierDisplay: "Gold Tier",
    distance: "80m – 150m",
    distanceNumber: 100,
    locationIndicator: "Markazia Shamalia (Northern Markazia)",
    shuttleOrWalk: "Walking Distance",
    description: "Step-out convenience into the illuminated plaza of Masjid an-Nabawi within 1 to 2 minutes.",
    relatedPackageCategory: "Gold"
  },
  {
    id: "madinah-louloat-al-madina",
    name: "Louloat Al Madina / Erjwaan Saada",
    city: "Madinah",
    tier: "Silver",
    tierDisplay: "Silver Tier",
    distance: "200m – 300m",
    distanceNumber: 250,
    locationIndicator: "Central Markazia Area, Madinah",
    shuttleOrWalk: "Walking Distance",
    description: "Prime mid-range hotel located close to key gates for both ladies' and gents' prayer entries.",
    relatedPackageCategory: "Silver"
  },
  {
    id: "madinah-hayah-plaza",
    name: "Hayah Plaza / Karam Golden",
    city: "Madinah",
    tier: "Silver",
    tierDisplay: "Silver Tier",
    distance: "250m – 300m",
    distanceNumber: 280,
    locationIndicator: "Markazia District, Madinah",
    shuttleOrWalk: "Walking Distance",
    description: "Neat modern rooms with fast elevators, tea facilities, and convenient pedestrian surroundings.",
    relatedPackageCategory: "Silver"
  },
  {
    id: "madinah-karam-al-madinah",
    name: "Karam Al Madinah / Karam Saada",
    city: "Madinah",
    tier: "Bronze",
    tierDisplay: "Bronze Tier",
    distance: "400m – 500m",
    distanceNumber: 450,
    locationIndicator: "Southern / Eastern Markazia",
    shuttleOrWalk: "Walking Distance",
    description: "Comfortable budget accommodations situated an easy 6 to 8 minutes leisurely stroll from the Haram.",
    relatedPackageCategory: "Bronze"
  },
  {
    id: "madinah-jawharat-al-rasheed",
    name: "Jawharat Al Rasheed / Mona Salam",
    city: "Madinah",
    tier: "Budget",
    tierDisplay: "Budget Tier",
    distance: "600m – 800m",
    distanceNumber: 700,
    locationIndicator: "Al Salam Street Area, Madinah",
    shuttleOrWalk: "Walking Distance",
    description: "Economical multi-bed property with peaceful atmosphere and straightforward walking access.",
    relatedPackageCategory: "Budget"
  }
];
