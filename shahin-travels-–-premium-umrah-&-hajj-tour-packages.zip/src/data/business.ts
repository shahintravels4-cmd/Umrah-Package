/**
 * Shahin Travels Business & Contact Information
 * 
 * Central business settings for Shahin Travels. Non-developers can update
 * phone numbers, email, address, and office details here directly.
 */

export const BUSINESS_INFO = {
  name: "Shahin Travels",
  subtitle: "HAJJ | UMRAH | TOURS | TRAVEL",
  phone: "9911446919",
  phoneDisplay: "+91 99114 46919",
  email: "Shahintravels@gmail.com",
  whatsappNumber: "919911446919", // Format with country code for wa.me links
  address: "Delhi & Mumbai Branch Operations, India",
  headline: "Your Journey to Umrah Begins Here",
  subheadline: "Plan your sacred journey with trusted travel assistance, comfortable stays and carefully selected Umrah packages.",
  disclaimer: "Package prices, hotel availability, airline schedules and departure dates may change. Please confirm current details with Shahin Travels before booking.",
  bookingNotice: "Prices are subject to airfare, hotel availability and applicable changes. Quad, triple and twin room sharing options are subject to seasonal revisions."
};

export const TRUST_POINTS = [
  {
    title: "Carefully Selected Packages",
    description: "Thoughtfully structured packages for every budget, from cost-effective options to luxury courtyard stays.",
    icon: "ShieldCheck"
  },
  {
    title: "Comfortable Hotel Options",
    description: "Verified hotels in Makkah and Madinah with transparent walking distances and 24/7 shuttle connectivity.",
    icon: "Building"
  },
  {
    title: "Flight Assistance",
    description: "Coordinated ticketing on Saudi Airlines direct departures, IndiGo, and cost-effective partner airlines.",
    icon: "Plane"
  },
  {
    title: "Visa Assistance",
    description: "End-to-end guidance for Umrah electronic visa issuance, documentation, and mandatory insurance.",
    icon: "FileCheck"
  },
  {
    title: "Ground Transportation",
    description: "Air-conditioned intercity transfers between Jeddah, Makkah, and Madinah including airport transit.",
    icon: "Bus"
  },
  {
    title: "Dedicated Customer Support",
    description: "Assistance by phone and WhatsApp throughout your sacred pilgrimage journey.",
    icon: "Headphones"
  }
];

export const JOURNEY_STEPS = [
  {
    step: "01",
    title: "Choose Your Package",
    description: "Select your preferred departure city (Delhi or Mumbai), hotel tier, duration, and airline."
  },
  {
    step: "02",
    title: "Submit Enquiry",
    description: "Reach out via WhatsApp or our enquiry form to verify real-time seat availability and exact dates."
  },
  {
    step: "03",
    title: "Confirm Booking",
    description: "Provide passport copies, pay the standard advance token deposit, and receive your booking confirmation."
  },
  {
    step: "04",
    title: "Prepare for Departure",
    description: "Receive your Umrah visa, flight tickets, hotel vouchers, and pre-departure pilgrim guidance kit."
  },
  {
    step: "05",
    title: "Begin Your Umrah Journey",
    description: "Embark on a peaceful pilgrimage with coordinated airport reception and dedicated on-ground care."
  }
];

export const UMRAH_GUIDES = [
  {
    id: "preparation-checklist",
    title: "Umrah Preparation Checklist",
    category: "Essential",
    readTime: "4 min read",
    summary: "Key physical, spiritual, and logistical preparations required before your flight.",
    details: [
      "Ensure passport validity of at least 6 months from travel date.",
      "Complete required medical vaccinations (Meningitis ACYW135 and seasonal flu as per Saudi guidelines).",
      "Pack digital and physical copies of Umrah e-visa, ticket, hotel vouchers, and passport.",
      "Familiarize yourself with Umrah rituals: Ihram, Niyyah, Tawaf, Sa'i, and Halq/Taqseer.",
      "Prepare a dua list for the sacred moments when laying eyes upon the Holy Kaaba."
    ]
  },
  {
    id: "what-to-pack",
    title: "What to Pack for Umrah",
    category: "Packing Guide",
    readTime: "3 min read",
    summary: "Comfortable, permissible packing essentials tailored for Makkah and Madinah climates.",
    details: [
      "For Men: 2 pairs of unstitched white cotton/terry Ihram towels, Ihram belt/pouch, and safety pins.",
      "For Women: Comfortable, modest abayas, breathable hijabs, under-caps, and non-slip prayer socks.",
      "Footwear: Comfortable slip-on sandals or cushioned walking shoes for long walks, plus shoe bags for the Haram.",
      "Toiletries: Unscented soap, unscented sunscreen, unscented moisturizer, and Vaseline for chafing prevention.",
      "Personal Meds: Rehydration salts (ORS), pain relievers, throat lozenges, and personal prescription medicines."
    ]
  },
  {
    id: "first-time-tips",
    title: "First-Time Umrah Tips",
    category: "Pilgrim Advice",
    readTime: "5 min read",
    summary: "Practical advice on managing crowds, prayer times, Zamzam, and rest intervals.",
    details: [
      "Perform Tawaf during cooler hours such as early morning before Duhr or late at night after Isha.",
      "Maintain hydration by drinking Zamzam water regularly from the designated coolers located throughout the Haram.",
      "Agree on an identifiable meeting landmark with your family members inside and outside the Haram gates.",
      "Download the official Nusuk mobile app for Rawdah shareef prayer reservation scheduling in Madinah.",
      "Pace your physical exertion: avoid rushing between prayer halls and rest sufficiently between rituals."
    ]
  },
  {
    id: "ihram-essentials",
    title: "Ihram Essentials & Rules",
    category: "Fiqh & Rules",
    readTime: "4 min read",
    summary: "Core prohibitions and best practices when entering the sacred state of Ihram.",
    details: [
      "Enter Ihram at or before the designated Miqat (for flights arriving in Jeddah, enter Ihram before boarding or in-flight).",
      "Make the formal Niyyah: 'Labbayka Allahumma Umrah' followed by reciting the Talbiyah.",
      "While in Ihram: Do not clip nails, shave or cut hair, apply scented perfume/oils, or cover the head (for men).",
      "Avoid arguments or harsh speech; focus the heart and tongue on Istighfar, Dhikr, and Quran recitation.",
      "Ihram concludes only after completing Tawaf, Sa'i between Safa and Marwah, and Taqseer (cutting hair)."
    ]
  },
  {
    id: "travel-documents",
    title: "Travel Documents & Requirements",
    category: "Documentation",
    readTime: "3 min read",
    summary: "Passport, visa, insurance, and photo specifications needed for hassle-free immigration.",
    details: [
      "Original passport with minimum 6 months validity and at least 2 blank adjacent visa pages.",
      "Recent passport-sized photographs with white background (2 x 2 inches or 35mm x 45mm).",
      "Valid Umrah E-Visa or Saudi Tourist eVisa processed through authorized travel systems.",
      "Mandatory Saudi medical insurance covering COVID-19 and emergency medical care (included in visa).",
      "Confirmed round-trip airline ticket and verified hotel accommodation confirmation."
    ]
  },
  {
    id: "faq",
    title: "Frequently Asked Questions",
    category: "FAQ",
    readTime: "4 min read",
    summary: "Clear answers to common questions about packages, flights, and payments.",
    details: [
      "Q: What is included in the package price?\nA: Most standard packages include return flights, Umrah visa with insurance, hotel accommodation in Makkah & Madinah, daily meals (buffet breakfast, lunch, dinner), air-conditioned ground transfers, and historical Ziyarat tours.",
      "Q: Can single women travel for Umrah?\nA: Yes, under current Saudi tourism regulations, women above 18 can perform Umrah without a Mahram in approved travel groups.",
      "Q: How far are the hotels from the Haram?\nA: Depending on your package tier, hotels range from 0–100m (Diamond/Luxury) to 200–500m (Gold/Silver) to 650–800m (Bronze) and 1500m with 24/7 shuttle (Budget).",
      "Q: How do I book a seat?\nA: Contact Shahin Travels via WhatsApp or phone (9911446919) to confirm seat availability, submit passport copies, and deposit the booking advance token."
    ]
  }
];

export const BOOKING_TERMS = [
  {
    title: "Room Sharing Basis",
    text: "Package rates are quoted per person on a sharing basis (Quad sharing basis unless Twin or Triple occupancy is specifically requested and booked). Single occupancy incurs additional room surcharges."
  },
  {
    title: "Price & Forex Fluctuation",
    text: "Published prices are based on prevailing airfare and Saudi Riyal (SAR) foreign exchange rates. Shahin Travels reserves the right to adjust rates in case of substantial airline fuel surcharges, tax changes, or currency devaluation prior to final ticket issuance."
  },
  {
    title: "Advance Deposit & Payment Schedule",
    text: "A non-refundable advance token payment of ₹40,000 per person is required to confirm bookings for departures scheduled more than 21 days out. The remaining balance must be cleared at least 21 days prior to the departure date."
  },
  {
    title: "Hotel Distance Clarification",
    text: "All distances specified in package descriptions are approximate walking meters from the hotel exterior to the nearest perimeter boundary of the Haram courtyard. Actual walking time may vary based on pedestrian traffic."
  },
  {
    title: "Flight & Airline Policies",
    text: "Group tickets are issued under airline group contract terms. Re-routing, individual cancellation, date change penalties, and luggage allowances are governed strictly by the respective carrier (Saudi Airlines, IndiGo, or partner LCCs)."
  },
  {
    title: "Unconfirmed Bookings",
    text: "Enquiries or tentative holds without payment of the initial booking deposit cannot be guaranteed. Seats and hotel allocations are released automatically if deadlines expire without payment receipt."
  }
];
