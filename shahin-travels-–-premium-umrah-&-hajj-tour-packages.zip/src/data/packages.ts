/**
 * Shahin Travels - Umrah Package Central Data Store
 * 
 * NOTE FOR OPERATORS / NON-DEVELOPERS:
 * To update package prices, departure dates, hotel details, or add new packages,
 * edit the objects in the PACKAGES array below. All filters, search results,
 * cards, modals, and WhatsApp links will update automatically.
 */

export interface UmrahPackage {
  id: string;
  name: string;
  category: "Budget" | "Bronze" | "Silver" | "Gold" | "Diamond";
  tierDisplay: string;
  departureCity: "Delhi" | "Mumbai";
  airline: "Saudi Airlines" | "IndiGo" | "LCC";
  airlineDisplay: string;
  duration: "14 Nights" | "15 Nights" | "20 Days";
  durationNights: number;
  departureDates: string[]; // e.g. ["1st & 15th Every Month", "Weekly Fixed Departures"]
  priceQuad: number | null; // null if unlisted/contact
  priceTriple?: number | null;
  priceDouble?: number | null;
  currency: string;
  
  // Makkah Details
  makkahHotel: string;
  makkahDistance: string;
  makkahTransport: string;
  
  // Madinah Details
  madinahHotel: string;
  madinahDistance: string;
  madinahTransport: string;
  
  // Inclusions & Highlights
  inclusions: string[];
  exclusions: string[];
  features: string[];
  isPopular?: boolean;
  notes?: string;
}

export const PACKAGES: UmrahPackage[] = [
  // =================== MUMBAI DEPARTURES ===================
  {
    id: "bom-saudi-gold-15n",
    name: "Mumbai Gold Saudi Airlines Umrah",
    category: "Gold",
    tierDisplay: "Gold Tier",
    departureCity: "Mumbai",
    airline: "Saudi Airlines",
    airlineDisplay: "Saudi Airlines (Direct Non-Stop)",
    duration: "15 Nights",
    durationNights: 15,
    departureDates: ["1st, 15th & 28th Every Month", "Custom Dates on Request"],
    priceQuad: 98786,
    priceTriple: 108786,
    priceDouble: 122786,
    currency: "INR",
    makkahHotel: "Mira Ajyad / Elaf Ajyad (or similar)",
    makkahDistance: "200m – 250m from Haram",
    makkahTransport: "Short walking distance directly to outer courtyard",
    madinahHotel: "Madina Baity / One Inn / Karam Golden",
    madinahDistance: "80m – 150m from Masjid an-Nabawi",
    madinahTransport: "Immediate walking access to Markazia courtyard",
    inclusions: [
      "Return airfare on Saudi Airlines direct scheduled flights",
      "Umrah electronic visa with mandatory medical insurance",
      "Hotel accommodation in Makkah (8 Nights) & Madinah (7 Nights)",
      "Daily Indian buffet meals (Breakfast, Lunch, Dinner)",
      "Air-conditioned luxury bus transfers (Jeddah - Makkah - Madinah - Airport)",
      "Guided historical Ziyarat tours in Makkah and Madinah with experienced scholar",
      "5 Litres packaged Zamzam water canister per pilgrim",
      "Complimentary Umrah pilgrim kit (Trolley bag, shoulder pouch, Tawaf tasbeeh, guide book)",
      "Laundry assistance service included (twice during stay)",
      "Rowda permit coordination support via Nusuk platform"
    ],
    exclusions: [
      "Any individual room service, laundry beyond package allowance, or personal telephone calls",
      "Excess baggage charges beyond standard airline allowance",
      "Expenses incurred due to unexpected flight cancellations or weather delays",
      "Optional tours or private vehicle hire"
    ],
    features: [
      "Direct Saudi Airlines Flights",
      "200m to 250m Makkah Walking",
      "80m to 150m Madinah Walking",
      "Full Indian Catering"
    ],
    isPopular: true,
    notes: "Prices subject to prevailing airfare & forex rate at time of confirmation."
  },
  {
    id: "bom-silver-indigo-15n",
    name: "Mumbai Silver IndiGo Umrah",
    category: "Silver",
    tierDisplay: "Silver Tier",
    departureCity: "Mumbai",
    airline: "IndiGo",
    airlineDisplay: "IndiGo Airlines (Direct / 1-Stop)",
    duration: "15 Nights",
    durationNights: 15,
    departureDates: ["5th, 12th, 20th & 27th Monthly"],
    priceQuad: 84786,
    priceTriple: 92786,
    priceDouble: 104786,
    currency: "INR",
    makkahHotel: "Waha Deafa / Mather Jawar / Tara Ajyad",
    makkahDistance: "450m – 500m from Haram",
    makkahTransport: "Easy 6–8 minute level pedestrian walk",
    madinahHotel: "Erjwaan Saada / Louloat Al Madina / Hayah Plaza",
    madinahDistance: "200m – 300m from Masjid an-Nabawi",
    madinahTransport: "Walking distance through northern Markazia",
    inclusions: [
      "Return flight tickets on IndiGo / scheduled partner airline",
      "Umrah visa and comprehensive health insurance",
      "15 Nights stay (Makkah & Madinah hotel allocations)",
      "Daily Indian menu meals prepared by authentic Indian chefs (3 times daily)",
      "Full AC bus transit between all holy cities and airports",
      "Local Ziyarat tours to historical landmarks (Jabal al-Noor, Ghar Thawr, Uhud, Quba)",
      "5L Zamzam canister per pilgrim upon departure",
      "Complimentary Shahin Travels travel kit & luggage tags",
      "On-ground tour manager assistance in Saudi Arabia"
    ],
    exclusions: [
      "Personal shopping and individual transport outside group schedule",
      "Room service and porterage tips",
      "Airline seat selection fees if requested individually"
    ],
    features: [
      "Comfortable Mid-Proximity Hotels",
      "All Indian Meals Included",
      "Complete Group Ziyarat",
      "Full Ground Transfers"
    ],
    isPopular: true,
    notes: "Standard quad sharing rate. Twin and triple rooms available on request."
  },
  {
    id: "bom-bronze-lcc-14n",
    name: "Mumbai Bronze Value Umrah",
    category: "Bronze",
    tierDisplay: "Bronze Tier",
    departureCity: "Mumbai",
    airline: "LCC",
    airlineDisplay: "Connecting LCC / Budget Carrier",
    duration: "14 Nights",
    durationNights: 14,
    departureDates: ["10th & 24th Every Month"],
    priceQuad: 75786,
    priceTriple: 82786,
    priceDouble: 92786,
    currency: "INR",
    makkahHotel: "Waref Al Deafa / Olayan Al Khalil (or similar)",
    makkahDistance: "650m – 800m from Haram",
    makkahTransport: "Approx. 10–12 minute walk to Haram boundaries",
    madinahHotel: "Karam Al Madinah / Karam Saada",
    madinahDistance: "400m – 500m from Masjid an-Nabawi",
    madinahTransport: "Walking distance through southern Markazia",
    inclusions: [
      "Return economy flight tickets",
      "Umrah visa processing and mandatory insurance",
      "14 Nights accommodation in approved hotels",
      "Daily Indian breakfast, lunch, and dinner buffet",
      "All transfers between Jeddah, Makkah, and Madinah via AC coaches",
      "Complete guided Ziyarat in Makkah and Madinah",
      "5L Zamzam box provided at airport return",
      "Experienced Indian group coordinator support"
    ],
    exclusions: [
      "Personal expenditure and individual laundry",
      "Excess baggage charges",
      "Unscheduled private transfers"
    ],
    features: [
      "Affordable Fixed Departure",
      "Indian Meals 3x Daily",
      "Full Group Ground Care",
      "Zamzam Included"
    ],
    notes: "Recommended for healthy adults and pilgrims seeking balance between budget and comfort."
  },
  {
    id: "bom-budget-shuttle-15n",
    name: "Mumbai Budget Shuttle Umrah",
    category: "Budget",
    tierDisplay: "Budget Tier",
    departureCity: "Mumbai",
    airline: "LCC",
    airlineDisplay: "LCC / Economy Airline",
    duration: "15 Nights",
    durationNights: 15,
    departureDates: ["Regular Monthly Departures", "Contact for Next Batch"],
    priceQuad: 67786,
    priceTriple: 74786,
    priceDouble: 83786,
    currency: "INR",
    makkahHotel: "Le Meridien Towers / Kiswah Towers / similar",
    makkahDistance: "1500m – 1800m from Haram",
    makkahTransport: "24/7 round-the-clock complimentary shuttle buses to Haram terminal",
    madinahHotel: "Jawharat Al Rasheed / Mona Salam / similar",
    madinahDistance: "600m – 800m from Masjid an-Nabawi",
    madinahTransport: "Level walking route or municipal transit",
    inclusions: [
      "Round-trip air ticket on budget carrier",
      "Umrah visa and government insurance coverage",
      "15 Nights hotel stay with 24/7 Makkah shuttle connectivity",
      "Full board Indian meals (Breakfast, Lunch, Dinner)",
      "Coordinated airport and inter-city coach transportation",
      "Makkah and Madinah Ziyarat visits",
      "Zamzam 5-litre allowance"
    ],
    exclusions: [
      "Any individual private transport outside group shuttle schedule",
      "Room telephone or individual laundry charges",
      "Meals during airport transit"
    ],
    features: [
      "Most Economical Full Package",
      "24/7 Free Makkah Shuttle",
      "Full Board Indian Catering",
      "Group Ziyarat Included"
    ],
    notes: "Great value for budget-conscious families and groups. Shuttles drop pilgrims directly at the Kudai / Ajyad terminal."
  },
  {
    id: "bom-luxury-diamond-14n",
    name: "Mumbai Diamond Courtyard Luxury Umrah",
    category: "Diamond",
    tierDisplay: "Diamond / Premium",
    departureCity: "Mumbai",
    airline: "Saudi Airlines",
    airlineDisplay: "Saudi Airlines (Direct Non-Stop)",
    duration: "14 Nights",
    durationNights: 14,
    departureDates: ["1st & 15th Every Month", "Private Dates on Request"],
    priceQuad: 144500,
    priceTriple: 158000,
    priceDouble: 178000,
    currency: "INR",
    makkahHotel: "Makkah Clock Royal Tower (Fairmont) / Swissôtel / Pullman Zamzam",
    makkahDistance: "0m – 50m (Direct Haram Courtyard Access)",
    makkahTransport: "Direct elevator access from tower lobby into Masjid al-Haram courtyard",
    madinahHotel: "Al Aqeeq Madinah / Dar Al Taqwa / Oberoi / Pullman Zamzam Madinah",
    madinahDistance: "0m – 50m from Masjid an-Nabawi",
    madinahTransport: "Direct step-out access to the main women's and men's prayer squares",
    inclusions: [
      "Direct Saudi Airlines flights in comfort economy or business upgrade option",
      "Express Umrah visa processing with priority clearance",
      "5-Star luxury hotel accommodation directly on the sacred courtyards",
      "Daily International and Indian buffet breakfast at 5-star hotel dining halls",
      "Private or VIP luxury coach transfers throughout the journey",
      "VIP private historical Ziyarat tour with personal guide",
      "Premium travel gift set and 5L Zamzam canister",
      "24/7 dedicated local relationship manager assistance"
    ],
    exclusions: [
      "Lunch and dinner (unless upgraded to half/full board)",
      "Personal spa, laundry, and hotel incidentals",
      "Gratuities and personal tips"
    ],
    features: [
      "Zero-Distance Courtyard Hotels",
      "Elevator Access to Haram",
      "Direct Saudi Airlines Flights",
      "VIP Ground Assistance"
    ],
    notes: "Ideal for elderly parents, families with infants, and pilgrims desiring maximum proximity and ease."
  },

  // =================== DELHI DEPARTURES ===================
  {
    id: "del-saudi-gold-15n",
    name: "Delhi Gold Saudi Airlines Umrah",
    category: "Gold",
    tierDisplay: "Gold Tier",
    departureCity: "Delhi",
    airline: "Saudi Airlines",
    airlineDisplay: "Saudi Airlines (Direct Non-Stop from IGI T3)",
    duration: "15 Nights",
    durationNights: 15,
    departureDates: ["3rd, 16th & 29th Every Month"],
    priceQuad: 99786,
    priceTriple: 109786,
    priceDouble: 124786,
    currency: "INR",
    makkahHotel: "Mira Ajyad / Premium Deafa Group Hotel",
    makkahDistance: "200m – 250m from Haram",
    makkahTransport: "Direct level pedestrian walk to Ajyad gate",
    madinahHotel: "Madina Baity / One Inn / Al Aqeeq Area",
    madinahDistance: "80m – 150m from Masjid an-Nabawi",
    madinahTransport: "Immediate walking access to the Prophet's Mosque courtyard",
    inclusions: [
      "Return airfare on direct Saudi Airlines non-stop flights from Delhi IGI",
      "Umrah electronic visa with mandatory government medical insurance",
      "15 Nights stay (8 Nights Makkah + 7 Nights Madinah)",
      "Buffet Indian meals three times daily (Breakfast, Lunch, Dinner)",
      "Fully air-conditioned luxury bus transportation for all sectors",
      "Comprehensive Ziyarat in Makkah (Mina, Arafat, Muzdalifah, Thawr, Noor) & Madinah (Quba, Qiblatayn, Uhud)",
      "5 Litres sealed Zamzam water container per pilgrim",
      "Pilgrim welcome kit with bag, shoe pouch, and prayer guide",
      "Assistance for Nusuk app appointment for Rawdah Sharifa"
    ],
    exclusions: [
      "Personal telephone calls, extra snacks, and individual laundry",
      "Excess baggage beyond airline allocation (standard 2 x 23kg + 7kg cabin)",
      "Domestic transit to Delhi IGI Airport"
    ],
    features: [
      "Direct Non-Stop Saudi Airlines",
      "200m Makkah Walking Proximity",
      "80m Madinah Proximity",
      "Full Board Indian Cuisine"
    ],
    isPopular: true,
    notes: "Prices subject to airline availability and Saudi Riyal exchange rate revisions."
  },
  {
    id: "del-silver-indigo-15n",
    name: "Delhi Silver IndiGo Umrah",
    category: "Silver",
    tierDisplay: "Silver Tier",
    departureCity: "Delhi",
    airline: "IndiGo",
    airlineDisplay: "IndiGo Airlines (Direct / Scheduled Connections)",
    duration: "15 Nights",
    durationNights: 15,
    departureDates: ["Every Thursday & Saturday Departures"],
    priceQuad: 87000,
    priceTriple: 95000,
    priceDouble: 106000,
    currency: "INR",
    makkahHotel: "Waha Deafa / Mather Jawar / Tara Ajyad",
    makkahDistance: "450m – 500m from Haram",
    makkahTransport: "Convenient walking distance (approximately 7 minutes)",
    madinahHotel: "Louloat Al Madina / Erjwaan Saada / Hayah Plaza",
    madinahDistance: "200m – 300m from Masjid an-Nabawi",
    madinahTransport: "Brief walk through illuminated northern Markazia lanes",
    inclusions: [
      "Return flight tickets on IndiGo / connecting flight",
      "Umrah visa issuing and health insurance coverage",
      "15 Nights hotel accommodation in clean, verified properties",
      "Fresh Indian meals (Breakfast, Lunch, Dinner) prepared by Indian catering team",
      "AC bus transfers across Jeddah, Makkah, and Madinah",
      "Guided Ziyarat tour with knowledgeable Urdu/Hindi-speaking guide",
      "5L Zamzam canister provided at Jeddah airport check-in",
      "Luggage tags, prayer booklet, and pilgrim ID card"
    ],
    exclusions: [
      "Expenses of personal nature and laundry service",
      "Tips to drivers or bellhops",
      "Optional visit to Taif or Badr (can be arranged on request)"
    ],
    features: [
      "Comfortable Walking Distance",
      "Authentic Indian Meals Daily",
      "Full AC Transit Fleet",
      "Professional Indian Escort"
    ],
    isPopular: true,
    notes: "One of the most preferred packages for family groups from Delhi & NCR."
  },
  {
    id: "del-bronze-lcc-14n",
    name: "Delhi Bronze Economy Umrah",
    category: "Bronze",
    tierDisplay: "Bronze Tier",
    departureCity: "Delhi",
    airline: "LCC",
    airlineDisplay: "LCC / Partner Connecting Carrier",
    duration: "14 Nights",
    durationNights: 14,
    departureDates: ["8th & 22nd Every Month"],
    priceQuad: 77786,
    priceTriple: 84786,
    priceDouble: 94786,
    currency: "INR",
    makkahHotel: "Waref Al Deafa / Olayan Al Khalil (or similar)",
    makkahDistance: "650m – 800m from Haram",
    makkahTransport: "Approx. 10–12 minutes walking",
    madinahHotel: "Karam Al Madinah / Karam Saada",
    madinahDistance: "400m – 500m from Masjid an-Nabawi",
    madinahTransport: "Walking distance through peaceful local streets",
    inclusions: [
      "Return airfare on scheduled LCC carrier",
      "Umrah visa and health coverage",
      "14 Nights hotel accommodation",
      "Three meals daily (Indian cuisine buffet)",
      "Coordinated group bus transit across all itinerary legs",
      "Ziyarat tours in both holy cities",
      "5 Litres Zamzam water",
      "Dedicated Shahin Travels on-site group leader"
    ],
    exclusions: [
      "Personal incidentals and telephone charges",
      "Individual transport outside scheduled group coach times"
    ],
    features: [
      "Budget-Conscious Pricing",
      "All Essential Meals Included",
      "Guided Ziyarat Tours",
      "Group Ground Handling"
    ],
    notes: "Transparent distances with no hidden charges. Reliable group departure."
  },
  {
    id: "del-budget-shuttle-14n",
    name: "Delhi Budget Shuttle Saver Umrah",
    category: "Budget",
    tierDisplay: "Budget Tier",
    departureCity: "Delhi",
    airline: "LCC",
    airlineDisplay: "LCC / Economy Airline",
    duration: "14 Nights",
    durationNights: 14,
    departureDates: ["10th & 25th Every Month"],
    priceQuad: 69786,
    priceTriple: 76786,
    priceDouble: 85786,
    currency: "INR",
    makkahHotel: "Le Meridien Towers / Kiswah Towers / similar",
    makkahDistance: "1500m – 1800m from Haram",
    makkahTransport: "Continuous 24/7 free shuttle service to Kudai / Ajyad terminal",
    madinahHotel: "Jawharat Al Rasheed / Karam Saada",
    madinahDistance: "600m – 800m from Masjid an-Nabawi",
    madinahTransport: "Walkable route or local shuttle connection",
    inclusions: [
      "Return airfare with budget scheduled airline",
      "Umrah visa processing and full health insurance",
      "14 Nights accommodation in approved multi-bed hotel rooms",
      "Buffet breakfast, lunch, and dinner with authentic Indian recipes",
      "Group AC coach transit for airport and intercity transfers",
      "Historical Ziyarat in Makkah and Madinah",
      "5 Litre Zamzam canister per pilgrim"
    ],
    exclusions: [
      "Individual taxi charges and personal shopping",
      "Laundry charges"
    ],
    features: [
      "Lowest Per-Person Cost",
      "24/7 Makkah Shuttle Fleet",
      "3 Indian Meals Every Day",
      "Complete Visa & Insurance"
    ],
    notes: "Affordable option designed for cost efficiency without compromising food quality or transport safety."
  },
  {
    id: "del-special-20days",
    name: "Delhi 20 Days Special Umrah Package",
    category: "Silver",
    tierDisplay: "Silver Tier (Extended Stay)",
    departureCity: "Delhi",
    airline: "IndiGo",
    airlineDisplay: "IndiGo / Connecting Scheduled Airline",
    duration: "20 Days",
    durationNights: 19,
    departureDates: ["1st & 15th of the Month (Subject to Schedule)"],
    priceQuad: 89786,
    priceTriple: 98786,
    priceDouble: 112786,
    currency: "INR",
    makkahHotel: "Waha Deafa / Tara Ajyad (10 Nights)",
    makkahDistance: "500m from Haram",
    makkahTransport: "Easy 7 minute walk to Haram boundary",
    madinahHotel: "Erjwaan Saada / Karam Al Madinah (10 Nights)",
    madinahDistance: "250m – 350m from Masjid an-Nabawi",
    madinahTransport: "Walking distance directly into northern courtyard",
    inclusions: [
      "Return airfare with 20-day validity ticket",
      "Umrah visa with comprehensive insurance",
      "20 Days accommodation (10 Nights Makkah + 10 Nights Madinah)",
      "Daily Indian buffet meals (Breakfast, Lunch, Dinner)",
      "Full AC coach transit between airports and holy cities",
      "Detailed historical Ziyarat tours in both Makkah & Madinah",
      "5L Zamzam canister at return",
      "Full group assistance and pilgrim kit"
    ],
    exclusions: [
      "Laundry beyond standard service",
      "Personal medical expenses beyond covered insurance"
    ],
    features: [
      "Extended 20 Days Pilgrimage",
      "10 Full Nights in Makkah",
      "10 Full Nights in Madinah",
      "All Indian Meals Included"
    ],
    notes: "Specially designed for pilgrims wishing to spend extra spiritual time in both holy sanctuaries."
  },
  {
    id: "del-luxury-diamond-15n",
    name: "Delhi Diamond Courtyard Luxury Umrah",
    category: "Diamond",
    tierDisplay: "Diamond / Premium",
    departureCity: "Delhi",
    airline: "Saudi Airlines",
    airlineDisplay: "Saudi Airlines (Direct Non-Stop from Delhi)",
    duration: "15 Nights",
    durationNights: 15,
    departureDates: ["Flexible Fixed Dates & Private Bookings"],
    priceQuad: 148500,
    priceTriple: 162000,
    priceDouble: 184000,
    currency: "INR",
    makkahHotel: "Makkah Clock Royal Tower (Fairmont) / Swissôtel Makkah",
    makkahDistance: "0m – 50m (Direct Haram Courtyard Access)",
    makkahTransport: "Direct lobby elevator to Masjid al-Haram entrance",
    madinahHotel: "Al Aqeeq Madinah / Dar Al Taqwa / Oberoi Hotel",
    madinahDistance: "0m – 50m from Masjid an-Nabawi",
    madinahTransport: "Direct step-out onto the main Prophet's Mosque courtyard",
    inclusions: [
      "Non-stop return flights on Saudi Airlines direct from Delhi IGI",
      "Express Umrah visa processing with priority clearance",
      "15 Nights luxury 5-star accommodation directly facing holy courtyards",
      "Sumptuous daily international and Indian buffet breakfasts",
      "Private VIP air-conditioned GMC / luxury coach transfers",
      "Dedicated historical Ziyarat tour with personal knowledgeable scholar",
      "Deluxe luggage kit and 5L sealed Zamzam water canister",
      "Personal on-call concierge assistance in Makkah & Madinah"
    ],
    exclusions: [
      "Lunch and dinner meals (can be added on request)",
      "Individual hotel room service, minibar, or spa treatments"
    ],
    features: [
      "Direct Non-Stop Flights",
      "Zero-Distance Luxury Stays",
      "Direct Elevator Access to Haram",
      "VIP Private Handling"
    ],
    notes: "The pinnacle of comfort and ease for families, elderly pilgrims, and private VIP groups."
  }
];

export const TIER_EXPLANATIONS = [
  {
    tier: "Budget",
    badge: "Budget Tier",
    headline: "For Affordable Umrah Travel",
    summary: "Reliable accommodation with 24/7 complimentary shuttle connectivity in Makkah and walkable stays in Madinah.",
    makkahDistance: "1500m – 1800m (with continuous 24/7 shuttle service)",
    madinahDistance: "600m – 800m (walking distance)",
    exampleHotels: "Le Meridien Towers, Kiswah Towers, Jawharat Al Rasheed",
    meals: "3 Indian meals daily (Buffet: Breakfast, Lunch, Dinner)",
    idealFor: "Cost-conscious pilgrims, youth groups, and individuals seeking essential pilgrimage support at the best possible price.",
    startingPrice: "₹67,786"
  },
  {
    tier: "Bronze",
    badge: "Bronze Tier",
    headline: "For Comfortable Stays With Better Proximity",
    summary: "Balanced packages with straightforward walking distance to Haram boundaries and dependable group services.",
    makkahDistance: "650m – 800m (approx. 10–12 minute walk)",
    madinahDistance: "400m – 500m (approx. 6–8 minute walk)",
    exampleHotels: "Waref Al Deafa, Olayan Al Khalil, Karam Al Madinah",
    meals: "Full board Indian catering (Breakfast, Lunch, Dinner)",
    idealFor: "Pilgrims who prefer walking directly to prayers without relying on shuttle buses while keeping expenses moderate.",
    startingPrice: "₹75,786"
  },
  {
    tier: "Silver",
    badge: "Silver Tier",
    headline: "For Enhanced Comfort and Location",
    summary: "Popular mid-range choice offering quality hotels within 450m to 500m in Makkah and 200m to 300m in Madinah.",
    makkahDistance: "450m – 500m (approx. 6–8 minute walk)",
    madinahDistance: "200m – 300m (approx. 3–5 minute walk)",
    exampleHotels: "Waha Deafa, Mather Jawar, Tara Ajyad, Erjwaan Saada",
    meals: "Full board Indian buffet prepared fresh daily",
    idealFor: "Families, working professionals, and pilgrims desiring closer walking proximity and elevated room quality.",
    startingPrice: "₹84,786"
  },
  {
    tier: "Gold",
    badge: "Gold Tier",
    headline: "For Premium Proximity and Facilities",
    summary: "High-comfort packages situated merely 200m to 250m from Makkah Haram and 80m to 150m from the Prophet's Mosque.",
    makkahDistance: "200m – 250m (approx. 3–4 minute walk)",
    madinahDistance: "80m – 150m (approx. 1–2 minute walk)",
    exampleHotels: "Mira Ajyad, Elaf Ajyad, Madina Baity, One Inn",
    meals: "Delicious 3-time Indian meals and beverages",
    idealFor: "Pilgrims with senior family members or children who require quick, effortless access to prayer halls for all 5 prayers.",
    startingPrice: "₹98,786"
  },
  {
    tier: "Diamond",
    badge: "Diamond / Premium",
    headline: "For Luxury and Closest-Location Options",
    summary: "Direct courtyard-facing 5-star properties offering zero-distance access and prestigious hospitality.",
    makkahDistance: "0m – 50m (Direct Haram Courtyard / Clock Tower)",
    madinahDistance: "0m – 50m (Direct Markazia Courtyard Access)",
    exampleHotels: "Makkah Clock Royal Tower (Fairmont), Swissôtel, Al Aqeeq, Dar Al Taqwa",
    meals: "5-Star buffet breakfast included (Lunch/Dinner upgradeable)",
    idealFor: "Pilgrims seeking highest standard of luxury, zero-commute convenience, and unmatched views of the sacred sanctuaries.",
    startingPrice: "₹1,44,500"
  }
];
