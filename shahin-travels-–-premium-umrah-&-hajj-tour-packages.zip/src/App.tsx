/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { TrustStrip } from './components/TrustStrip';
import { PackageFinder } from './components/PackageFinder';
import { PackageTierSection } from './components/PackageTierSection';
import { HotelSection } from './components/HotelSection';
import { WhyChooseUs } from './components/WhyChooseUs';
import { JourneyTimeline } from './components/JourneyTimeline';
import { UmrahGuide } from './components/UmrahGuide';
import { BookingTerms } from './components/BookingTerms';
import { ContactSection } from './components/ContactSection';
import { Footer } from './components/Footer';
import { FloatingWhatsApp } from './components/FloatingWhatsApp';
import { PackageDetailModal } from './components/PackageDetailModal';
import { EnquiryModal } from './components/EnquiryModal';
import { UmrahPackage } from './data/packages';

export default function App() {
  const [selectedPackage, setSelectedPackage] = useState<UmrahPackage | null>(null);
  const [isEnquiryOpen, setIsEnquiryOpen] = useState(false);
  const [enquiryPackageName, setEnquiryPackageName] = useState<string | undefined>(undefined);
  const [tierFilterTrigger, setTierFilterTrigger] = useState<string>('All');

  // Smooth scroll to packages section and apply tier filter if clicked from tier or hotel section
  const handleSelectTier = (tierName: string) => {
    setTierFilterTrigger(tierName);
    const element = document.getElementById('packages');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleOpenEnquiry = (packageName?: string) => {
    setEnquiryPackageName(packageName);
    setIsEnquiryOpen(true);
  };

  const handleExplorePackages = () => {
    const element = document.getElementById('packages');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#FAF8F3] text-[#1F2933] antialiased">
      {/* 1. Header / Navbar */}
      <Navbar onOpenEnquiry={handleOpenEnquiry} />

      {/* Main Content Area */}
      <main className="flex-1">
        {/* 2. Hero Section */}
        <Hero onExplorePackages={handleExplorePackages} />

        {/* 3. Quick Trust Strip */}
        <TrustStrip />

        {/* 4. Umrah Package Finder & Filtering System */}
        <PackageFinder
          onViewDetails={(pkg) => setSelectedPackage(pkg)}
          onEnquireNow={(pkg) => handleOpenEnquiry(pkg.name)}
          initialCategory={tierFilterTrigger}
        />

        {/* 5. Package Tier Comparison Section */}
        <PackageTierSection onSelectTier={handleSelectTier} />

        {/* 6. Dedicated Hotels Section (Makkah & Madinah) */}
        <HotelSection onSelectTier={handleSelectTier} />

        {/* 7. Why Choose Shahin Travels */}
        <WhyChooseUs />

        {/* 8. Umrah Journey Timeline */}
        <JourneyTimeline />

        {/* 9. Umrah Guide & Educational Cards */}
        <UmrahGuide />

        {/* 10. Important Booking Terms & Policies */}
        <BookingTerms />

        {/* 11. Final Contact / Enquiry Section */}
        <ContactSection onOpenEnquiry={() => handleOpenEnquiry()} />
      </main>

      {/* 12. Premium Dark Navy Footer */}
      <Footer />

      {/* 13. Floating WhatsApp Quick Action */}
      <FloatingWhatsApp />

      {/* 14. Modals */}
      <PackageDetailModal
        pkg={selectedPackage}
        onClose={() => setSelectedPackage(null)}
        onOpenEnquiry={(pkgName) => handleOpenEnquiry(pkgName)}
      />

      <EnquiryModal
        isOpen={isEnquiryOpen}
        onClose={() => setIsEnquiryOpen(false)}
        defaultPackageName={enquiryPackageName}
      />
    </div>
  );
}
